package com.alibaba.fastjson.parser.deserializer;


public interface ParseProcess {

}
