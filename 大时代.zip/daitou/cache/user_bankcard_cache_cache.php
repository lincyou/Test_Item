<?php
return array (
  22 => 
  array (
    'id' => '22',
    'bank_card' => '',
    'bank_name' => '',
    'user_group' => '1,2,3,4',
    'bank_title' => '支',
    'pic_url' => 'http://daitou.01717.com/upload/bankcard/b05265dd42e508ef7af1c1b40dbfbe38.jpg',
    'stuat' => '1',
    'beizhu' => '',
    'typeid' => '2',
    'realname' => '',
    'min_money' => '0',
  ),
  'group' => 
  array (
    1 => 
    array (
      2 => 
      array (
        0 => 
        array (
          0 => '22',
        ),
        1000 => 
        array (
          0 => '21',
        ),
      ),
      1 => 
      array (
        0 => 
        array (
          0 => '20',
        ),
        1000 => 
        array (
          0 => '19',
        ),
      ),
      3 => 
      array (
        0 => 
        array (
          0 => '18',
        ),
        1000 => 
        array (
          0 => '16',
        ),
      ),
    ),
    2 => 
    array (
      2 => 
      array (
        0 => 
        array (
          0 => '22',
        ),
        1000 => 
        array (
          0 => '21',
        ),
      ),
      1 => 
      array (
        0 => 
        array (
          0 => '20',
        ),
        1000 => 
        array (
          0 => '19',
        ),
      ),
      3 => 
      array (
        0 => 
        array (
          0 => '18',
        ),
        1000 => 
        array (
          0 => '16',
        ),
      ),
    ),
    3 => 
    array (
      2 => 
      array (
        0 => 
        array (
          0 => '22',
        ),
        1000 => 
        array (
          0 => '21',
        ),
      ),
      1 => 
      array (
        0 => 
        array (
          0 => '20',
        ),
        1000 => 
        array (
          0 => '19',
        ),
      ),
      3 => 
      array (
        0 => 
        array (
          0 => '18',
        ),
        1000 => 
        array (
          0 => '16',
        ),
      ),
    ),
    4 => 
    array (
      2 => 
      array (
        0 => 
        array (
          0 => '22',
        ),
        1000 => 
        array (
          0 => '21',
        ),
      ),
      1 => 
      array (
        0 => 
        array (
          0 => '20',
        ),
        1000 => 
        array (
          0 => '19',
        ),
      ),
      3 => 
      array (
        0 => 
        array (
          0 => '18',
        ),
        1000 => 
        array (
          0 => '16',
        ),
      ),
    ),
  ),
  21 => 
  array (
    'id' => '21',
    'bank_card' => '',
    'bank_name' => '',
    'user_group' => '1,2,3,4',
    'bank_title' => '1000支',
    'pic_url' => 'http://daitou.01717.com/upload/bankcard/0bb88ae6ba534929efa62cf68c8624d6.jpg',
    'stuat' => '1',
    'beizhu' => '1000支支支',
    'typeid' => '2',
    'realname' => '',
    'min_money' => '1000',
  ),
  20 => 
  array (
    'id' => '20',
    'bank_card' => '22222222222222222222',
    'bank_name' => '22222222222222222',
    'user_group' => '1,2,3,4',
    'bank_title' => '卡',
    'pic_url' => '',
    'stuat' => '1',
    'beizhu' => '',
    'typeid' => '1',
    'realname' => '卡0',
    'min_money' => '0',
  ),
  19 => 
  array (
    'id' => '19',
    'bank_card' => '11111111111111111111',
    'bank_name' => '11111111111111',
    'user_group' => '1,2,3,4',
    'bank_title' => '1000卡',
    'pic_url' => '',
    'stuat' => '1',
    'beizhu' => '',
    'typeid' => '1',
    'realname' => '1000卡',
    'min_money' => '1000',
  ),
  18 => 
  array (
    'id' => '18',
    'bank_card' => '',
    'bank_name' => '',
    'user_group' => '1,2,3,4',
    'bank_title' => '微',
    'pic_url' => 'http://daitou.01717.com/upload/bankcard/6f2cd4ef44776c5838a9888858d98f4d.jpg',
    'stuat' => '1',
    'beizhu' => '',
    'typeid' => '3',
    'realname' => '',
    'min_money' => '0',
  ),
  16 => 
  array (
    'id' => '16',
    'bank_card' => '',
    'bank_name' => '',
    'user_group' => '1,2,3,4',
    'bank_title' => '1000微',
    'pic_url' => 'http://daitou.01717.com/upload/bankcard/2dfa49c2cbd674f5459a1d4cfba46866.jpg',
    'stuat' => '1',
    'beizhu' => '',
    'typeid' => '3',
    'realname' => '',
    'min_money' => '1000',
  ),
);
?>