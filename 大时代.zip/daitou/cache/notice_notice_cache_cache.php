<?php
return array (
  3 => 
  array (
    'id' => '3',
    'title' => '测试网站公告测试网站公告测试网站公告测试网站公告测试网站公告',
    'infos' => '<span style="color:#454545;font-family:" font-size:14px;background-color:#ffffff;"="">1234567</span>',
    'add_time' => '1497588274',
    'admin_id' => '1',
    'typeid' => '1',
  ),
  'typelist' => 
  array (
    1 => 
    array (
      0 => '3',
    ),
  ),
  'list' => 
  array (
    0 => '3',
  ),
);
?>