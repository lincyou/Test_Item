﻿timers = null; //聊天定时器(滚动加载方法中用的)
timers_end = null; //聊天定时器(滚动加载方法中用的)
var form_stuat = 0;
var aurl_stuat = 0;
var licai_stuat = 0;
//聊天加载历史数据
function LoadingDataFn() {
	var dom = '';
	var chat_time = 0;
	var lar = '';
	var info = '';
	var last_i = $('#chat_start_time');
	$('.load_msg').show();
	jQuery.ajax({
		url: './load_msg.html',
		data: 'chat_start_time=' + last_i.val() + '&info_type=1',
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				for(var i = json.list.length - 1; i >= 0; i--){
					info = '';
					if(json.list[i].type == 1){
						lar = 'left';
					}else{
						lar = 'right';
					}
					if(json.list[i].typeid == 1){
						info = json.list[i].msg;
					}else{
						info = '<img style="width:100%" src="' + upload_url + json.list[i].msg + '">';
					}
					dom += '<div class="chat-widget-' + lar + '" id="chat_' + json.list[i].time + '">' + info + '</div>';
				}
				if(last_i.val() == 0){
					$("#chat_end_time").val(json.chat_end_time);
				}
				chat_time = json.chat_start_time;
				$('.chat-widget-main').prepend(dom);
				if(last_i.val() != 0){
					$('.chat-widget-main').scrollTop($('#chat_' + last_i.val()).position().top - $('#chat_' + last_i.val()).height() - 30);
				}
				last_i.val(json.chat_start_time);
				timers = null;
			}else if(json.stuat == 3 && chat_time > 0){
				alert('没有更多消息！');
			}else if(chat_time > 0){
				alert(json.msg);
			}
		},
	});
	$('.load_msg').hide();
};

//聊天加载最新数据
function LoadingDataNew(){
	var timestamp = Date.parse(new Date()) / 1000;
	if(timestamp >= msg_end_load_time && timers_end == null){
		timers_end = 3;
		var dom = '';
		var chat_time = 0;
		var lar = '';
		var info = '';
		var last_i = $('#chat_end_time');
		jQuery.ajax({
			url: './load_msg.html',
			data: 'chat_end_time=' + last_i.val() + '&info_type=2',
			type: "POST",
			beforeSend: function() {
			},
			success: function(msg) {
				var json = eval("(" + msg + ")");
				if(json.stuat == 1){
					for(var i = 0; i <= json.list.length - 1; i++){
						info = '';
						if(json.list[i].type == 1){
							lar = 'left';
						}else{
							lar = 'right';
						}
						if(json.list[i].typeid == 1){
							info = json.list[i].msg;
						}else{
							info = '<img style="width:100%" src="' + upload_url + json.list[i].msg + '">';
						}
						dom += '<div class="chat-widget-' + lar + '" id="chat_' + json.list[i].time + '">' + info + '</div>';
					}
					if($("#chat_start_time").val() == 0){
						$("#chat_start_time").val(json.chat_start_time);
					}
					$('.chat-widget-main').append(dom);
					last_i.val(json.chat_end_time);
				}
			},
		});
		msg_end_load_time = timestamp + 30;
	}
	timers_end = null;
}

//发送聊天信息
function post_msg(msg_type, msg_info){
	jQuery.ajax({
		url: './post_msg.html',
		data: 'msg_type=' + msg_type + '&msg_info=' + msg_info,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				if(timers_end == null){
					msg_end_load_time = Date.parse(new Date()) / 1000;
					LoadingDataNew();
				}
				$('#msg_info').val('');
				$('.chat-widget-main').scrollTop($('.chat-widget-main')[0].scrollHeight);
			}else{
				alert(json.msg);
			}
		},
	});
}

$(document).ready(function() {
	if($("#msg_upload_img").length > 0){
		$('#msg_upload_img').uploadify({
			formData      : {'type' : 'msg'},
			removeTimeout 	 : 0,
			method	         : 'POST',
			fileTypeDesc	 : '注意:您只能上图片格式的文件!',
			'swf'      : 'upload/uploadify.swf',
			'uploader' : 'upload/uploadify.php',
			'fileTypeExts' : '*.jpg;*.png;*.gif',
			multi: true,
			auto             : true,
			onUploadSuccess  : function(file, data, response) {{
				var json = eval("(" + data + ")");
				if(json.rename != undefined){
					post_msg(2, json.rename);
				}else{
					alert('上传图片失败，请重试！');
				}
			}}
		});
	}
	//如果聊天存在则初始化聊天
	if($(".chat-widget-main").length > 0){
		LoadingDataFn();
		timers_end = setInterval(function() {
			LoadingDataNew(); //调用执行上面的加载方法
		}, 10000);
		$("#post_msg").click(function(){
			var msg_info = $("#msg_info").val();
			post_msg(1, msg_info);
		});
		$('.chat-widget-main').scrollTop($('.chat-widget-main')[0].scrollHeight);
	}

	if($("#zhifubaopic").length > 0){
	$('#zfbupload').uploadify({
		formData      : {'type' : 'erweima'},
		removeTimeout 	 : 0,
		method	         : 'POST',
		fileTypeDesc	 : '注意:您只能上图片格式的文件!',
		'swf'      : 'upload/uploadify.swf',
		'uploader' : 'upload/uploadify.php',
		'fileTypeExts' : '*.jpg;*.png;*.gif',
		multi: true,
		auto             : true,
		onUploadSuccess  : function(file, data, response) {{
			var json = eval("(" + data + ")");
			if(json.rename != undefined){
				var pic_url = 'upload/' + json.rename;
				$('#zfbpic_url').val(pic_url);
				$('#zfbpic').attr('src', pic_url);
			}else{
				alert('上传图片失败，请重试！');
			}
		}}
	});
	$('#wxupload').uploadify({
		formData      : {'type' : 'erweima'},
		removeTimeout 	 : 0,
		method	         : 'POST',
		fileTypeDesc	 : '注意:您只能上图片格式的文件!',
		'swf'      : 'upload/uploadify.swf',
		'uploader' : 'upload/uploadify.php',
		'fileTypeExts' : '*.jpg;*.png;*.gif',
		multi: true,
		auto             : true,
		onUploadSuccess  : function(file, data, response) {{
			var json = eval("(" + data + ")");
			if(json.rename != undefined){
				var pic_url = 'upload/' + json.rename;
				$('#wxpic_url').val(pic_url);
				$('#wxpic').attr('src', pic_url);
			}else{
				alert('上传图片失败，请重试！');
			}
		}}
	});
		$("#zhifubaopic, #weixinpic").mouseover(function(){
			var uppicid = $(this).attr('id');
			$("." + uppicid).show();
		});
		$(".up_img").mouseout(function(){
			$(".up_img").hide();
		});
	}
	if($(".submit_form").length > 0){
		var form_stuat = $('#forminfo').attr('stuat');
		if(form_stuat == undefined){
			$('#forminfo').attr('stuat', 0);
			form_stuat = 0;
		}
	}
});

//聊天滚动加载方法
$('.chat-widget-main').scroll(function() {
	//当时滚动条离顶部60px时开始加载下一页的内容
	if($(this)[0].scrollTop <= 60 && timers == null) {
		clearTimeout(timers);
		//这里还可以用 [ 延时执行 ] 来控制是否加载 （这样就解决了 当上页的条件满足时，一下子加载多次的问题啦）
		timers = setTimeout(function() {
			LoadingDataFn(); //调用执行上面的加载方法
		}, 300);
	}
});

//申请理财计划
$('.simple-table').click(function(){
	if(licai_stuat == 1){
		return false;
	}
	if(confirm('您确认消费积分购买/升级该理财计划吗？确认后无法退回！')){
		licai_stuat = 1;
		var class_name = $(this).attr('class').split(' ');
		var add_licai_money = 0;
		if(class_name[0] == 'licai-tong'){
			add_licai_money = 1000; 
		}else if(class_name[0] == 'licai-lan'){
			add_licai_money = 2000;
		}else if(class_name[0] == 'licai-huang'){
			add_licai_money = 5000;
		}
		if(add_licai_money >= 1){
			jQuery.ajax({
				url: './add_licai.html',
				data: 'money=' + add_licai_money,
				type: "POST",
				beforeSend: function() {
				},
				success: function(msg) {
					var json = eval("(" + msg + ")");
					if(json.stuat == 1){
						alert(json.msg);
						window.location.reload();
					}else{
						alert(json.msg);
					}
				},
			});
		}
		setTimeout(lcs, 1000);
	}
	return false;
});

//领取任务
$('#get_task').click(function(){
	if(form_stuat == 1){
		return false;
	}
	form_stuat = 1;
	jQuery.ajax({
		url: 'get_task.html',
		data: 'get=yes',
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				$('#task_info').html('当前任务 | ' + json.money);
				alert('领取任务成功，请下注' + json.money + '元，任务扣除' + json.task_money + '积分，中奖后获得' + json.jl_money + '积分');
			}else if(json.stuat == 3){
				window.location.href = "./taskuser.html";
			}else{
				alert(json.msg);
			}
		},
	});
	setTimeout(fps, 1000);
});

//表单递交
$('.submit_form').click(function(){
	/*
	if(form_stuat == 1){
		return false;
	}
	*/
	form_stuat = 1;
	var form_url = $('#forminfo').attr('action');
	var form_info = $('#forminfo').serialize();
	if(form_url.length > 8 && form_info.length > 3){
		jQuery.ajax({
			url: form_url,
			data: form_info,
			type: "POST",
			beforeSend: function() {
			},
			success: function(msg) {
				var json = eval("(" + msg + ")");
				if(json.group == 1){
					group_fuceng(msg);
				}else{
					alert(json.msg);
				}
			},
		});
	}
	//setTimeout(fps, 1000);
});

function group_fuceng(msg){
	var json = eval("(" + msg + ")");
	$('#username').html(json.username);
	$('#password').html(json.password);
	$(".modal-backdrop, .modal").show();
}

//关闭浮窗
$('.close_win').click(function(){
	$(".modal-backdrop, .modal").hide();
});

function pages(page, url, divid){
	jQuery.ajax({
		url: url,
		data: 'page=' + page,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				$('#' + divid).html(json.html)
			}else{
				alert(json.msg);
			}
		},
	});
}

//AJAX递交
function aurl(url, id){
	if(aurl_stuat == 1){
		return false;
	}
	aurl_stuat = 1;
	jQuery.ajax({
		url: url,
		data: 'id=' + id,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.rehtml == 1){
				pages(1, 'sell_list_api.html', 'sell_list');
				pages(1, 'mybuy_list_api.html', 'mybuy_list');
			}else if(json.rehtml == 2){
				pages(1, 'mysell_list_api.html', 'mysell_list');
			}else if(json.rehtml == 3){
				pages(1, 'mybuy_list_api.html', 'mybuy_list');
			}
			alert(json.msg);
		}
	});
	setTimeout(cas, 1000);
	return false;
}

function cas(){
	aurl_stuat = 0;
}

function lcs(){
	licai_stuat = 0;
}

function fps(){
	form_stuat = 0;
}

function buyinfo(id){
	jQuery.ajax({
		url: './center_info.html',
		data: 'id=' + id,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				if(json.weixin != ''){
					$("#wx_pic").attr('src', json.weixin);
					$("#wx_money").show();
				}else{
					$("#wx_money").hide();
				}
				if(json.zhifubao != ''){
					$("#zfb_pic").attr('src', json.zhifubao);
					$("#zfb_money").show();
				}else{
					$("#zfb_money").hide();
				}
				if(json.yh_info != ''){
					$("#yh_info").html(json.yh_info);
					$("#yh_money").show();
				}else{
					$("#yh_money").hide();
				}
				if(json.username != ''){
					$("#username_info").html(json.username);
					$("#username").show();
				}else{
					$("#username").hide();
				}
				if(json.mobile != ''){
					$("#mobile_info").html(json.mobile);
					$("#mobile").show();
				}else{
					$("#mobile").hide();
				}
				$(".modal-backdrop, #myModal").show();
			}else{
				alert(json.msg);
			}
		}
	});
}

function sellinfo(id){
	jQuery.ajax({
		url: './center_buyuser.html',
		data: 'id=' + id,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				if(json.username != ''){
					$("#buy_username_info").html(json.username);
					$("#buy_username").show();
				}else{
					$("#buy_username").hide();
				}
				if(json.mobile != ''){
					$("#buy_mobile_info").html(json.mobile);
					$("#buy_mobile").show();
				}else{
					$("#buy_mobile").hide();
				}
				$(".modal-backdrop, #sellModal").show();
			}else{
				alert(json.msg);
			}
		}
	});
}