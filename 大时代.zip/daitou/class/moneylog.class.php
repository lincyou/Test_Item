<?php
class moneylog extends base_model{
	function __construct() {
		parent::__construct();
		$this->table = 'moneylog';
		$this->primarykey = array('id');
		$this->maxcol = 'id';
	}
	
	public function create($arr) {
		$arr['id'] = $this->add($arr);
		if($arr['id'] >= 1) {
			return $arr['id'];
		} else {
			return 0;
		}
	}
	
	public function create1($arr) {
		empty($arr['id']) && $arr['id'] = $this->maxid('+1');
		if($this->set($arr['id'], $arr)) {
			$this->count('+1');
			return $arr['id'];
		} else {
			$this->maxid('-1');
			return 0;
		}
	}
	
	public function update($uid, $arr) {
		return $this->set($uid, $arr);
	}
	
	public function read($uid) {
		return $this->get($uid);
	}

	public function _delete($uid) {
		$return = $this->delete($uid);
		if($return) {
			$this->count('-1');
		}
		return $return;
	}

	public function totypeid() {
		$return = array(
			1 => '充值入款',
			2 => '提现出款',
			3 => '投注扣款',
			4 => '中奖派奖',
			5 => '代理佣金',
			6 => '后台加款',
			7 => '后台扣款',
			8 => '优惠活动',
			9 => '提现取消',
			10 => '充值撤销',
		);
		return $return;
	}
}
?>