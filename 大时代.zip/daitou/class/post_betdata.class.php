<?php
class post_betdata extends base_model{
	function __construct() {
		parent::__construct();
		include FRAMEWORK_PATH.'lib/Snoopy.class.php';
		$this->snoopy = new Snoopy;
		$this->_dama = $this->_form = $this->_cookies = $this->_siteuser = array();
		$this->_dama['username'] = 'chenlong';
		$this->_dama['password'] = '8888888chenlong';
		$this->_dama['codetype'] = '4004';
		$this->_dama['appid'] = '2855';
		$this->_dama['appkey'] = '296a4adc5c0ffb5b3d08d58ce10fcf2d';
		$this->_dama['timeout'] = '60';
		$this->_siteuser['username1'] = '';//网站1用户名
		$this->_siteuser['password1'] = '';//网站1用户密码
		$this->_siteuser['username2'] = 'xiaoya15';//网站2用户名
		$this->_siteuser['password2'] = '123456';//网站2用户密码
		$this->_site2_list = array(
			0 => array(
				1 => array(
					'playId' => 142151010,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '冠军',
				),
				2 => array(
					'playId' => 142151011,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '冠军',
				),
				3 => array(
					'playId' => 142151012,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '冠军',
				),
				4 => array(
					'playId' => 142151013,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '冠军',
				),
				5 => array(
					'playId' => 142151014,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '冠军',
				),
				6 => array(
					'playId' => 142151015,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '冠军',
				),
				7 => array(
					'playId' => 142151016,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '冠军',
				),
				8 => array(
					'playId' => 142151017,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '冠军',
				),
				9 => array(
					'playId' => 142151018,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '冠军',
				),
				10 => array(
					'playId' => 142151019,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '冠军',
				),
			),
			1 => array(
				1 => array(
					'playId' => 142151110,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '亚军',
				),
				2 => array(
					'playId' => 142151111,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '亚军',
				),
				3 => array(
					'playId' => 142151112,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '亚军',
				),
				4 => array(
					'playId' => 142151113,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '亚军',
				),
				5 => array(
					'playId' => 142151114,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '亚军',
				),
				6 => array(
					'playId' => 142151115,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '亚军',
				),
				7 => array(
					'playId' => 142151116,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '亚军',
				),
				8 => array(
					'playId' => 142151117,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '亚军',
				),
				9 => array(
					'playId' => 142151118,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '亚军',
				),
				10 => array(
					'playId' => 142151119,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '亚军',
				),
			),
			2 => array(
				1 => array(
					'playId' => 142151210,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '季军',
				),
				2 => array(
					'playId' => 142151211,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '季军',
				),
				3 => array(
					'playId' => 142151212,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '季军',
				),
				4 => array(
					'playId' => 142151213,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '季军',
				),
				5 => array(
					'playId' => 142151214,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '季军',
				),
				6 => array(
					'playId' => 142151215,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '季军',
				),
				7 => array(
					'playId' => 142151216,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '季军',
				),
				8 => array(
					'playId' => 142151217,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '季军',
				),
				9 => array(
					'playId' => 142151218,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '季军',
				),
				10 => array(
					'playId' => 142151219,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '季军',
				),
			),
			3 => array(
				1 => array(
					'playId' => 142151310,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第四名',
				),
				2 => array(
					'playId' => 142151311,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第四名',
				),
				3 => array(
					'playId' => 142151312,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第四名',
				),
				4 => array(
					'playId' => 142151313,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第四名',
				),
				5 => array(
					'playId' => 142151314,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第四名',
				),
				6 => array(
					'playId' => 142151315,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第四名',
				),
				7 => array(
					'playId' => 142151316,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第四名',
				),
				8 => array(
					'playId' => 142151317,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第四名',
				),
				9 => array(
					'playId' => 142151318,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第四名',
				),
				10 => array(
					'playId' => 142151319,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第四名',
				),
			),
			4 => array(
				1 => array(
					'playId' => 142151410,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第五名',
				),
				2 => array(
					'playId' => 142151411,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第五名',
				),
				3 => array(
					'playId' => 142151412,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第五名',
				),
				4 => array(
					'playId' => 142151413,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第五名',
				),
				5 => array(
					'playId' => 142151414,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第五名',
				),
				6 => array(
					'playId' => 142151415,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第五名',
				),
				7 => array(
					'playId' => 142151416,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第五名',
				),
				8 => array(
					'playId' => 142151417,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第五名',
				),
				9 => array(
					'playId' => 142151418,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第五名',
				),
				10 => array(
					'playId' => 142151419,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第五名',
				),
			),
			5 => array(
				1 => array(
					'playId' => 142151510,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第六名',
				),
				2 => array(
					'playId' => 142151511,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第六名',
				),
				3 => array(
					'playId' => 142151512,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第六名',
				),
				4 => array(
					'playId' => 142151513,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第六名',
				),
				5 => array(
					'playId' => 142151514,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第六名',
				),
				6 => array(
					'playId' => 142151515,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第六名',
				),
				7 => array(
					'playId' => 142151516,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第六名',
				),
				8 => array(
					'playId' => 142151517,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第六名',
				),
				9 => array(
					'playId' => 142151518,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第六名',
				),
				10 => array(
					'playId' => 142151519,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第六名',
				),
			),
			6 => array(
				1 => array(
					'playId' => 142151610,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第七名',
				),
				2 => array(
					'playId' => 142151611,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第七名',
				),
				3 => array(
					'playId' => 142151612,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第七名',
				),
				4 => array(
					'playId' => 142151613,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第七名',
				),
				5 => array(
					'playId' => 142151614,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第七名',
				),
				6 => array(
					'playId' => 142151615,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第七名',
				),
				7 => array(
					'playId' => 142151616,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第七名',
				),
				8 => array(
					'playId' => 142151617,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第七名',
				),
				9 => array(
					'playId' => 142151618,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第七名',
				),
				10 => array(
					'playId' => 142151619,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第七名',
				),
			),
			7 => array(
				1 => array(
					'playId' => 142151710,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第八名',
				),
				2 => array(
					'playId' => 142151711,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第八名',
				),
				3 => array(
					'playId' => 142151712,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第八名',
				),
				4 => array(
					'playId' => 142151713,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第八名',
				),
				5 => array(
					'playId' => 142151714,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第八名',
				),
				6 => array(
					'playId' => 142151715,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第八名',
				),
				7 => array(
					'playId' => 142151716,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第八名',
				),
				8 => array(
					'playId' => 142151717,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第八名',
				),
				9 => array(
					'playId' => 142151718,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第八名',
				),
				10 => array(
					'playId' => 142151719,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第八名',
				),
			),
			8 => array(
				1 => array(
					'playId' => 142151810,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第九名',
				),
				2 => array(
					'playId' => 142151811,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第九名',
				),
				3 => array(
					'playId' => 142151812,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第九名',
				),
				4 => array(
					'playId' => 142151813,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第九名',
				),
				5 => array(
					'playId' => 142151814,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第九名',
				),
				6 => array(
					'playId' => 142151815,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第九名',
				),
				7 => array(
					'playId' => 142151816,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第九名',
				),
				8 => array(
					'playId' => 142151817,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第九名',
				),
				9 => array(
					'playId' => 142151818,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第九名',
				),
				10 => array(
					'playId' => 142151819,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第九名',
				),
			),
			9 => array(
				1 => array(
					'playId' => 142151910,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '01',
					'buyCodeFront' => '01',
					'playTypeName' => '第十名',
				),
				2 => array(
					'playId' => 142151911,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '02',
					'buyCodeFront' => '02',
					'playTypeName' => '第十名',
				),
				3 => array(
					'playId' => 142151912,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '03',
					'buyCodeFront' => '03',
					'playTypeName' => '第十名',
				),
				4 => array(
					'playId' => 142151913,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '04',
					'buyCodeFront' => '04',
					'playTypeName' => '第十名',
				),
				5 => array(
					'playId' => 142151914,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '05',
					'buyCodeFront' => '05',
					'playTypeName' => '第十名',
				),
				6 => array(
					'playId' => 142151915,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '06',
					'buyCodeFront' => '06',
					'playTypeName' => '第十名',
				),
				7 => array(
					'playId' => 142151916,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '07',
					'buyCodeFront' => '07',
					'playTypeName' => '第十名',
				),
				8 => array(
					'playId' => 142151917,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '08',
					'buyCodeFront' => '08',
					'playTypeName' => '第十名',
				),
				9 => array(
					'playId' => 142151918,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '09',
					'buyCodeFront' => '09',
					'playTypeName' => '第十名',
				),
				10 => array(
					'playId' => 142151919,
					'imp' => 0,
					'moneyUnit' => 3,
					'singleMoney' => 0,//金额，1表示1分钱
					'rebateRate' => 0,
					'buyCode' => '10',
					'buyCodeFront' => '10',
					'playTypeName' => '第十名',
				),
			),
		);
	}
	
	public function load_site_1(){
		$this->snoopy->referer = "http://h.kfun222.com/Account/Login"; 
		//获取token才能进入首页
		$url = 'http://h.kfun222.com/auth?url=%2FAccount%2FLogin';
		$this->snoopy->fetch($url);
		//cookie需要去除后面的换行
		foreach($this->snoopy->cookies as $k => $v){
			$this->snoopy->cookies[$k] = trim($v);
			$this->_cookies[] = $k.'='.trim($v);
		}
		$this->snoopy->rawheaders["COOKIE"] = implode("; ", $this->snoopy->cookies);
		$url = "http://h.kfun222.com/Account/Login";
		$this->snoopy->fetch($url);
		if(!empty($this->snoopy->headers)){
			foreach($this->snoopy->headers as $k => $v){
				preg_match('/Set-Cookie:(.*);/iU',$v, $str);
				if(!empty($str[1])){
					$new_cookies = trim($str[1]); //获得COOKIE（SESSIONID）
					$new_cookies_list = explode("=", $new_cookies);
					$new_cookies_name = $new_cookies_list[0];
					unset($new_cookies_list[0]);
					$new_cookies_value = implode("=", $new_cookies_list);
					$this->_cookies[] = $new_cookies;
				}
			}
			$this->snoopy->rawheaders["COOKIE"] = implode("; ", $this->_cookies);
		}
		preg_match('/type="hidden" value="(.*)"/iU', $this->snoopy->results, $new_token);
		$this->_form['__RequestVerificationToken'] = $new_token[1];
	}
	
	public function login_1(){
		$token_url = '';
		$username = 'fafa888';
		$password = 'qwer0810';
		$data = array(
			'__RequestVerificationToken' => $this->_form['__RequestVerificationToken'],
			'LoginID' => $username,
			'Password' => $password,
			'CaptchaDeText' => $this->_form['CaptchaDeText'],
			'CaptchaInputText' => '',
			'SkipTradeAgreement' => 'false',
		);
	}
	
	public function check_login_1() {
		$url = "https://h.kfun222.com/Home/GetWalletAmount";
	}
	
	public function get_login_code_1() {
		$this->load_site_1();
		print_r($this->snoopy);
		$url = "http://h.kfun222.com/Account/Captcha";
		$data = array(
			'CaptchaError' => 'False',
		);
		$a = $this->snoopy->submit($url, $data);
		//正则取出验证码token
		preg_match('/type="hidden" value="(.*)"/iU',$this->snoopy->results, $code_token);
		$this->_form['CaptchaDeText'] = $code_token[1];
		$code = $this->get_login_decode_1($code_token[1]);
		//print_r($this->snoopy);exit;
		if(!empty($code)){
			return $code;
		}else{
			return $this->get_login_code_1();
		}
	}
	
	public function get_login_decode_1($code_token, $num = 1){
		$code_pic = BBS_PATH."yzm/".$code_token.".gif";
		if(!file_exists($code_pic)){
			$url = "http://h.kfun222.com/DefaultCaptcha/Generate?t=".$code_token;
			$this->snoopy->fetch($url);
			if($num == 1){
				foreach($this->snoopy->headers as $k => $v){
					preg_match('/Set-Cookie:(.*);/iU',$v, $str);
					if(!empty($str[1])){
						$new_cookies = trim($str[1]); //获得COOKIE（SESSIONID）
						$this->_cookies[] = $new_cookies;
					}
				}
				$this->snoopy->rawheaders["COOKIE"] = implode("; ", $this->_cookies);
				$num += 1;
				return $this->get_login_decode_1($code_token, $num);
			}
			if(!empty($this->snoopy->results) and $this->snoopy->status == 200){
				file_put_contents($code_pic, $this->snoopy->results);
			}
			print_r($this->snoopy);
			exit;
		}
		//设置POST类型
		$cid = 0;
		$this->snoopy->_submit_type = 'multipart/form-data';
		//$formvars['file'] = './yzm.gif';
		//设置提交文件
		$postfiles['file'] = $code_pic;
		//设置提交URL
		$action = "http://api.yundama.com/api.php?method=upload";
		$this->snoopy->submit($action, $this->_dama, $postfiles);
		if(!empty($this->snoopy->results)){
			$data = json_decode($this->snoopy->results);
			if(!empty($data['cid'])){
				$cid = $data['cid'];
			}
		}
		$code_info = '';
		if($cid >= 1){
			sleep(2);
			$code_info = $this->decode($cid);
		}
		return $code_info;
	}
	
	//获取网站1余额并检测在线
	public function site1_money($num = 1, $site1_cookie = array()){
		if($this->conf['site1_login'] == 2){
			return array('stuat' => -2, 'money' => 0);
		}
		if($num > 5){
			$this->login_1();
			return array('stuat' => -1, 'money' => 0);
		}
		if(empty($site1_cookie)){
			$site1_cookie = $this->mcache->read('site1_cookie');
		}
		$url = "http://api2-287.zcgsrg.com/cloud/api/user.balance.get";
		$data = array(
			'json' => '{"jsonrpc":"2.0","method":"user.balance.get","params":{"sessionId":"'.$site2_cookie['sessionId'].'","terminal":1}}',
		);
		$this->snoopy->submit($url, $data);
		if(!empty($this->snoopy->results)){
			$data1 = json_decode($this->snoopy->results, true);
			//print_r($data1);
			if(isset($data1['result']['balance'])){
				return array('stuat' => 1, 'money' => $data1['result']['balance']);
			}else if(isset($data1['result']) and empty($data1['result']['balance'])){
				$cookie = $this->login_2();
				$num += 1;
				return $this->site2_money($num, $cookie);
			}else{
				$num += 1;
				return $this->site2_money($num);
			}
		}
	}
	
	//从手机版登录网站2，由于手机版彩票停止，已经废弃
	public function login_21(){
		$this->snoopy->referer = "http://www.55557.com/default.html";
		$url = 'http://api1-263.zcgsyq.com/cloud/api/auth.mobile.login';
		$data = array(
			'json' => '{"id":"41456059667327","jsonrpc":"2.0","method":"auth.mobile.login","params":{"sn":"pd00","loginId":"xiaoya15","withAuth":"1","withProfile":"1","saltedPassword":"HHwGrs/x4CDCu7YQzmSMtUPNCos=","salt":1541456059667,"terminal":8}}',
		);
		$this->snoopy->submit($url, $data);
		if(!empty($this->snoopy->results)){
			$json = json_decode($this->snoopy->results);
			if(!empty($json['result']['sessionId'])){
			}
		}
		print_r($this->snoopy);exit;
	}
	
	//从电脑版登录网站2
	public function login_2($num = 1){
		if($num > 5){
			return array('stuat' => 2);
		}
		$site2_cache = array();
		$code = $this->site2_code();
		if($code['stuat'] != 1){
			$num += 1;
			return $this->login_2($num);
		}
		$this->snoopy->referer = "http://www.55557.com/default.html";
		$this->snoopy->_submit_type = 'application/x-www-form-urlencoded';
		$url = 'http://tapi2.zcgshm.com/cloud/api/auth.login';
		$data = array(
			'json' => '{"id":"41457428884934","jsonrpc":"2.0","method":"auth.login","params":{"sn":"pd00","loginId":"xiaoya15","saltedPassword":"ARSpPAi7sSPxR0gfdWZwSVAMaQs=","salt":1541457428884,"captchaKey":'.$code['key'].',"captchaCode":"'.$code['code'].'","withAuth":"1","withProfile":"1","withBalance":"1","terminal":1}}',
		);
		$this->snoopy->submit($url, $data);
		if(!empty($this->snoopy->results)){
			$json = json_decode($this->snoopy->results, true);
			if(!empty($json['result']['sessionId'])){
				$site2_cache = array('sessionId' => $json['result']['sessionId']);
				$diy_cache = $this->mcache->diysave('site2_cookie', $site2_cache);
				return array('stuat' => 1, 'sessionId' => $json['result']['sessionId']);//登录成功
			}else{
				$num += 1;
				return $this->login_2($num);//登录失败
			}
		}else{
			$num += 1;
			return $this->login_2($num);//登录失败
		}
	}
	
	//获得网站2验证码
	public function site2_code($num = 1){
		if($num > 5){
			return array('stuat' => 2);
		}
		$key = rand(10000000, 99999999);
		$url = "http://api1-263.zcgsyq.com/cloud/api.do?pa=captcha.next&key=".$key;
		$code_pic = BBS_PATH."yzm/".$key.".png";
		$this->snoopy->fetch($url);
		if(!empty($this->snoopy->results) and $this->snoopy->status == 200){
			file_put_contents($code_pic, $this->snoopy->results);
			sleep(1);
			$code = $this->piccode_decode($code_pic);
			if($code['stuat'] == 1){
				return array('stuat' => 1, 'code' => $code['code'], 'key' => $key);
			}else{
				$num += 1;
				return $this->site2_code($num);
			}
		}else{
			$num += 1;
			return $this->site2_code($num);
		}
	}
	
	//获取网站2余额并检测在线
	public function site2_money($num = 1, $site2_cookie = array()){
		if($this->conf['site2_login'] == 2){
			return array('stuat' => -2, 'money' => 0);
		}
		if($num > 5){
			$this->login_2();
			return array('stuat' => -1, 'money' => 0);
		}
		if(empty($site2_cookie)){
			$site2_cookie = $this->mcache->read('site2_cookie');
		}
		$url = "http://api2-287.zcgsrg.com/cloud/api/user.balance.get";
		$data = array(
			'json' => '{"jsonrpc":"2.0","method":"user.balance.get","params":{"sessionId":"'.$site2_cookie['sessionId'].'","terminal":1}}',
		);
		$this->snoopy->submit($url, $data);
		if(!empty($this->snoopy->results)){
			$data1 = json_decode($this->snoopy->results, true);
			//print_r($data1);
			if(isset($data1['result']['balance'])){
				return array('stuat' => 1, 'money' => $data1['result']['balance']);
			}else if(isset($data1['result']) and empty($data1['result']['balance'])){
				$cookie = $this->login_2();
				$num += 1;
				return $this->site2_money($num, $cookie);
			}else{
				$num += 1;
				return $this->site2_money($num);
			}
		}
	}
	
	//网站1递交投注
	public function site1_bet($bet, $bet1, $qihao, $num = 1, $site1_cookie = array()){
		if(empty($bet) and empty($bet1)){
			return array('stuat' => 1);//不需要投注
		}
		if($this->conf['site1_login'] == 2){
			return array('stuat' => -2, 'money' => 0);
		}
		if($num > 5){
			return array('stuat' => -1);
		}
		/*
		$site1_cookie['cookie'] = '__cfduid=ddc1bbf666d8afc832ee3dcf1215cc34b1541524819; __RequestVerificationToken=2HIh7cRI7nGAxAOzstP3wl6Fdk7l94kUwKnwR9C28RDwqYXfMtb1R8AsJH5RPwtMBbuIL4D7Zzer2jkb1qEJIk2wv2b9PYHu8ywFyjNoOlI1; ASP.NET_SessionId=gfqqsumcohs1gaqabj3zoxzc; .AspNet.ApplicationCookie=w0BQFpuRDphwN5SHFunIHAv-CnvgADmYBWr1KgnKtpTUTrdOm3EppV8UJFaRT1671zPNhIM91ljGR9WvKog05qx6ajN74e80aPuMPMRtbWexiZXtwxZLtkMlgKz9_f_ypaCvX8ZbjDhCl7aMm4e8hOyPYtrK4UVRq6xTFFHhHJ5Boal2rtOSk1hlatf61J5aIulRm6r21ijxWS_rV5BKdu63ASirk-AmqKlKtiQ0N-yi1SqdZTquwVawqJJS8TQdvDVUH9GLa_HKRUWJsz5d1XF5wzFeRyOobbUVBRJyzCSEjnhlL82LvSpmip5LuplK4SXY30XCjhL0bXSOD6EZOLgQfucKUP4_NeO3arN2emKZcSB_JRscY7bkBXK-rJbYDRMNLSEcu_iUMxpcJb44_ITjAy8WD3TH9iam-rTKruqDHLtPaFEx6oAEl-gVhs0kD7-jHWfGUj-4kMD-Zs903vKKR6fuG7QWXe04acnXzF1586n3xNxpmFo9AJVM4mxP0NzSmBQKYOIqcilRVOpsd_kyLNQw_p8tLcNYC74Ycs8';
		$site1_cookie['cookie'] = '__cfduid=dfd1069d955ec13385f45bd69921c88601541525043; __RequestVerificationToken=TeYybJMbuZRa1ip3UU9O6dGzWxTpnvt_1P1twZYwNu6mAy4pWNK-eZw_Ijcl62cqZvtek49P2wTWL-c0Y0MYaNiClGqYASPIx0myNv2NZlM1; ASP.NET_SessionId=q4ondx1dv5l50gnulpntxrdb; .AspNet.ApplicationCookie=K2KGYKFhT9vvLW91a9XW5YG0CDSEICVDCNLuS-DC5iCktlvLjuYcq2dEIJ4bg-XeZtMXHDL9OtWfvzGG13HMWaoco8Ha2_zauZDn2PZj1zXXCE03n26M82fv2Bkl2pm-GE1Z7QNp9DdUT7C4hBP5USFyNku0bnDUVzD-AqC2Bi9LYvJlDcpAJzeJKIN3luWIcM1SLa1FGYzr9Ua_TGBBuSXKwAXJZu90JwrrowG_LoqpqpbjE_1XaBEbj9k9pTyR8r2y9nY7qKr8dwZxLkRHfBUDAJgAokTWFBlchDDjaFw9LkfxnbjVndEGbVqVsT2V3ZCYZPXCGvus-2Vipb34bm0fAWBhWtWfrjNcdx-nDlf7pKQPpZHq9W5l1ssdp-nAudK2WqmYPPeqAII3PT-rxlrN5SQ674rm9bB0eoFftr2e428T6NgjKpXj1vzKiozj3nWqFteP3Q-LbUQocUnUA6ofus7W-X4X2rbsHswkTQTOG6IXqgL6ZALGNU375lEVYMVovdzMQtBuQfT_GaIz0Dk5OhE4BfIeL9va8ERYkRc';
		$site1_cookie['guid'] = '12b223f4-7838-a86c-055d-f8499e9e4397';
		
		$site1_cookie['guid'] = '05989de3-8ad8-8454-ecb8-1022e710d917';
		*/
		//$sn = 'pd00';
		if(empty($site1_cookie)){
			$site1_cookie = $this->mcache->read('site1_cookie');
		}
		$url = "http://c.ykyl8888.com/Bet/Confirm";
		$data = array(
			'BetMode' => 0,
			'Guid' => $site1_cookie['guid'],
			'IsLoginByWeChat' => false,
			'LotteryGameID' => 19,
			'Schedules' => array(),
			'StopIfWin' => false,
			'SerialNumber' => $qihao,
			'Bets' => '',
		);
		$list_data = array(
			'BetTypeCode' => 0,
			'BetTypeName' => '',
			'IsCompressed' => false,
			'Multiple' => 1,
			'NoCommission' => false,
			'Number' => '',
			'Position' => '',
			'ReturnRate' => 0,
			'Unit' => 0,
		);
		$dingwei_id = 3007;
		$guanya_id = 3003;
		$info_data = $jieguo_data = array();
		$exp_info = explode("|", $bet);
		foreach($exp_info as $k => $v){
			$exp_data = explode("_", $v);
			if(!empty($exp_data)){
				foreach($exp_data as $ek => $ev){
					$exp_data1 = explode(",", $ev);
					$touzhu = array();
					if(!empty($exp_data1)){
						foreach($exp_data1 as $k2 => $v2){
							$exp_data2 = explode(":", $v2);
							if(!empty($exp_data2[1])){
								$touzhu[$exp_data2[0]] = $exp_data2[1];
							}
						}
					}
					$jieguo_data[] = $touzhu;
				}
			}
		}
		$dingwei_array = array(
			0 => '',
			1 => '',
			2 => '',
			3 => '',
			4 => '',
			5 => '',
			6 => '',
			7 => '',
			8 => '',
			9 => '',
		);
		if(!empty($jieguo_data)){
			foreach($jieguo_data as $k => $v){
				if(empty($v)){
					unset($v);
				}else{
					foreach($v as $k1 => $v1){
						$number = $dingwei_array;
						$number[$k] = str_pad($k1,2,"0",STR_PAD_LEFT);
						$touzhu_data = $list_data;
						$touzhu_data['BetTypeCode'] = $dingwei_id;
						$touzhu_data['Number'] = implode(",", $number);
						$touzhu_data['Unit'] = 
						$touzhu_data['Unit'] = 0.001;
						$touzhu_data['Multiple'] = $v1 * 1000;
						$betList[] = $touzhu_data;
					}
				}
			}
		}
		$info_data = $jieguo_data = array();
		if(!empty($bet1)){
			$exp_info = explode("|", $bet1);
			foreach($exp_info as $k => $v){
				$exp_data = explode(":", $v);
				$exp_data1 = explode("_", $exp_data[0]);
				$bet2_haoma = str_pad($exp_data1[0],2,"0",STR_PAD_LEFT).','.str_pad($exp_data1[1],2,"0",STR_PAD_LEFT);
				$jieguo_data1[$bet2_haoma] = $exp_data[1];
			}
		}
		if(!empty($jieguo_data1)){
			foreach($jieguo_data1 as $k1 => $v1){
				$touzhu_data = $list_data;
				$touzhu_data['BetTypeCode'] = $guanya_id;
				$touzhu_data['Number'] = $k1;
				$touzhu_data['Unit'] = 0.001;
				$touzhu_data['Multiple'] = $v1 * 1000;
				$betList[] = $touzhu_data;
			}
		}
		//$data['Bets'] = json_encode($betList, JSON_UNESCAPED_UNICODE);
		//$data['Bets'] = $betList;
		$data['Bets'][] = array(
			'BetTypeCode' => 3003,
			'BetTypeName' => '',
			'Number' => '09,08',
			'Position' => '',
			'Unit' => 0.001,
			'Multiple' => 2,
			'ReturnRate' => 0,
			'IsCompressed' => false,
			'NoCommission' => false,
		);
		$post_key = json_encode($data, JSON_UNESCAPED_UNICODE);
		//echo $post_key;exit;
		$post_data[$post_key] = '';
		$header=array(
			"Cache-Control: no-cache", 
			"Pragma: no-cache", 
			"Accept: application/json",
			"Content-Type: application/json;charset=utf-8",
		);
		//echo $post_key;exit;
		$results = $this->za->curlPost($url, $post_key, 3, 60, $site1_cookie['cookie'], $header);
		//print_r($a);exit;
		//$this->snoopy->cookies = $cookie_array;
		//$this->snoopy->_submit_type = 'application/json; charset=utf-8';
		//$url = 'http://c.ykyl8888.com/Home/GetWalletAmount';
		//$this->snoopy->fetch($url);
		//print_r($this->snoopy);exit;
		//$this->snoopy->submit($url, $post_data);
		//print_r($this->snoopy);exit;
		//$results = $this->za->curlPost($url, $post_data);
		$json_results = json_decode($results, true);
		if(!empty($json_results['LotteryGameID'])){
			if(!empty($json_results['BetDatas'])){
				//投注成功
				return array('stuat' => 1);
			}else{
				$num += 1;
				return $this->site1_bet($bet, $qihao, $num, $site2_cookie);
			}
		}else{
			$num += 1;
			return $this->site1_bet($bet, $qihao, $num, $site2_cookie);
		}
	}
	
	//网站2递交投注
	public function site2_bet($bet, $bet1, $qihao, $num = 1, $site2_cookie = array()){
		if(empty($bet) and empty($bet1)){
			return array('stuat' => 1);//不需要投注
		}
		if($this->conf['site2_login'] == 2){
			return array('stuat' => -2, 'money' => 0);
		}
		if($num > 5){
			return array('stuat' => -1);
		}
		$site2_cookie['sessionId'] = 'DEMO03A4505010E5EBC37D51E207ab38';
		//$sn = 'pd00';
		$sn = 'DEMO';
		if(empty($site2_cookie)){
			$site2_cookie = $this->mcache->read('site2_cookie');
		}
		$url = "http://api2-287.zcgsrg.com/lottery-wapi/wapi/LotteryUserBet";
		$data = array(
			'cmd' => 'LotteryUserBet',
			'lotteryId' => 1401,
			'issue' => $qihao,
			'winningToStop' => 1,
			'betList' => '',
			'clientType' => 1,
			'channel' => 'bg',
			'version' => '1.0',
			'token' => $site2_cookie['sessionId'],
			'identity' => '',
			'sn' => $sn,
		);
		$list_data = array(
			'playId' => 141111010,
			'buyCode' => '',
			'buyCodeFront' => '',
			'singleMoney' => 0,
			'buyDouble' => 1,
			'moneyUnit' => 3,
			'rebateRate' => 0,
			'imp' => 0,
		);
		$info_data = $jieguo_data = array();
		$exp_info = explode("|", $bet);
		foreach($exp_info as $k => $v){
			$exp_data = explode("_", $v);
			if(!empty($exp_data)){
				foreach($exp_data as $ek => $ev){
					$exp_data1 = explode(",", $ev);
					$touzhu = array();
					if(!empty($exp_data1)){
						foreach($exp_data1 as $k2 => $v2){
							$exp_data2 = explode(":", $v2);
							if(!empty($exp_data2[1])){
								$touzhu[$exp_data2[0]] = $exp_data2[1];
							}
						}
					}
					$jieguo_data[] = $touzhu;
				}
			}
		}
		if(!empty($jieguo_data)){
			foreach($jieguo_data as $k => $v){
				if(empty($v)){
					unset($v);
				}else{
					foreach($v as $k1 => $v1){
						$touzhu_data = $this->_site2_list[$k][$k1];
						$touzhu_data['singleMoney'] = $v1 * 100;
						$betList[] = $touzhu_data;
					}
				}
			}
		}
		$info_data = $jieguo_data = array();
		if(!empty($bet1)){
			$exp_info = explode("|", $bet1);
			foreach($exp_info as $k => $v){
				$exp_data = explode(":", $v);
				$exp_data1 = explode("_", $exp_data[0]);
				$bet2_haoma = str_pad($exp_data1[0],2,"0",STR_PAD_LEFT).','.str_pad($exp_data1[1],2,"0",STR_PAD_LEFT);
				$jieguo_data1[$bet2_haoma] = $exp_data[1];
			}
		}
		if(!empty($jieguo_data1)){
			foreach($jieguo_data1 as $k1 => $v1){
				$touzhu_data = $list_data;
				$touzhu_data['buyCode'] = $touzhu_data['buyCodeFront'] = $k1;
				$touzhu_data['singleMoney'] = $v1 * 100;
				$betList[] = $touzhu_data;
			}
		}
		$data['betList'] = json_encode($betList, JSON_UNESCAPED_UNICODE);
		$post_key = json_encode($data, JSON_UNESCAPED_UNICODE);
		$post_data[$post_key] = '';
		$results = $this->za->curlPost($url, $post_data);
		$json_results = json_decode($results, true);
		//print_r($json_results);exit;
		if(!empty($json_results['identity'])){
			if(isset($json_results['desc']) and $json_results['desc'] == 'success'){
				//投注成功
				return array('stuat' => 1);
			}else{
				$num += 1;
				return $this->site2_bet($bet, $qihao, $num, $site2_cookie);
			}
		}else{
			$num += 1;
			return $this->site2_bet($bet, $qihao, $num, $site2_cookie);
		}
	}
	
	//上传打码图片
	public function piccode_decode($pic, $num = 1){
		if($num > 5){
			return array('stuat' => 2);
		}
		//设置POST类型
		$cid = 0;
		$this->snoopy->_submit_type = 'multipart/form-data';
		//$formvars['file'] = './yzm.gif';
		//设置提交文件
		$postfiles['file'] = $pic;
		//设置提交URL
		$action = "http://api.yundama.com/api.php?method=upload";
		$this->snoopy->submit($action, $this->_dama, $postfiles);
		if(!empty($this->snoopy->results)){
			$data = json_decode($this->snoopy->results, true);
			if(!empty($data['cid'])){
				$cid = $data['cid'];
			}else{
				$num += 1;
				return $this->piccode_decode($pic, $num);
			}
		}else{
			$num += 1;
			return $this->piccode_decode($pic, $num);
		}
		$code_info = '';
		if($cid >= 1){
			sleep(2);
			$code_info = $this->decode($cid);
			if($code_info['stuat'] == 1){
				return $code_info;
			}else{
				return array('stuat' => 2);
			}
		}
	}
	
	//获取打码结果验证码
	public function decode($cid, $num = 1){
		if($num > 5){
			return array('stuat' => 2, 'money' => 0);
		}
		$url = 'http://api.yundama.com/api.php?cid='.$cid.'&method=result';
		$this->snoopy->fetch($url);
		if(!empty($this->snoopy->results)){
			$data = json_decode($this->snoopy->results, true);
			if(!empty($data['text'])){
				return array('stuat' => 1, 'code' => $data['text']);;
			}else{
				sleep(1);
				$num += 1;
				return $this->decode($cid, $num);
			}
		}
	}
	
	//获取打码平台余额
	public function decode_money($num = 1){
		if($num > 5){
			return array('stuat' => 2, 'money' => 0);
		}
		$url = 'http://api.yundama.com/api.php?method=balance';
		$this->snoopy->submit($url, $this->_dama);
		if(!empty($this->snoopy->results)){
			$data = json_decode($this->snoopy->results, true);
			if(isset($data['balance'])){
				return array('stuat' => 1, 'money' => $data['balance']);
			}else{
				$num += 1;
				return $this->decode_money($num);
			}
		}
	}

	//进入北京赛车url https://lotv1up2.clavarck.com/pc/lobby/#/1401?token=pd00033F6521150F8C560D5179B5f75f&sn=pd00&skins=10
}
?>