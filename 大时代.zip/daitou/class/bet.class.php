<?php
class bet extends base_model{
	function __construct() {
		parent::__construct();
		$this->table = 'bet';
		$this->primarykey = array('id');
		$this->maxcol = 'id';
	}
	
	public function create($arr) {
		$arr['id'] = $this->add($arr);
		if($arr['id'] >= 1) {
			return $arr['id'];
		} else {
			return 0;
		}
	}
	
	public function create1($arr) {
		empty($arr['id']) && $arr['id'] = $this->maxid('+1');
		if($this->set($arr['id'], $arr)) {
			$this->count('+1');
			return $arr['id'];
		} else {
			$this->maxid('-1');
			return 0;
		}
	}
	
	public function update($uid, $arr) {
		return $this->set($uid, $arr);
	}
	
	public function read($uid) {
		return $this->get($uid);
	}

	public function _delete($uid) {
		$return = $this->delete($uid);
		if($return) {
			$this->count('-1');
		}
		return $return;
	}

	public function wanfa() {
		$return = array(
			1 => '定位胆',
			2 => '冠亚组合',
		);
		return $return;
	}

	public function stuat() {
		$return = array(
			1 => '待开奖',
			2 => '中奖',
			3 => '未中奖',
			4 => '撤销',
		);
		return $return;
	}

	public function typeid() {
		$return = array(
			1 => '自动',
			2 => '手动',
		);
		return $return;
	}

	public function typeid1() {
		$return = array(
			1 => '投注类型1',
			2 => '投注类型2',
		);
		return $return;
	}

	public function format_info1($info, $num = 1, $fenge = '<br>'){
		$infos = '';
		if(!empty($info)){
			$info_data = $jieguo_data = array();
			$exp_info = explode("|", $info);
			foreach($exp_info as $k => $v){
				$exp_data = explode("_", $v);
				if(!empty($exp_data)){
					foreach($exp_data as $ek => $ev){
						$exp_data1 = explode(",", $ev);
						$jieguo_data[] = $exp_data1;
					}
				}
			}
			if(!empty($jieguo_data)){
				foreach($jieguo_data as $k => $v){
					if(empty($v[0]) and empty($v[1])){
						unset($v);
					}
					if(!empty($v)){
						$ming = $k + 1;
						$info_data[] = '第'.$ming.'名：'.implode(",", $v);
					}
				}
			}
			$infos = implode($fenge, $info_data);
		}
		return $infos;
	}
	
	//格式化玩法2数据
	public function wanfa2_change($info){
		$infos = '';
		if(!empty($info)){
			$info_data = array();
			$exp_data = explode("_", $info);
			if(!empty($exp_data)){
				foreach($exp_data as $ek => $ev){
					$exp_data1 = explode(",", $ev);
					$jieguo_data[] = $exp_data1;
				}
			}
			$info_list = array();
			for($i = 0; $i < count($jieguo_data[0]); $i++){
				for($is = 0; $is < count($jieguo_data[1]); $is++){
					if($jieguo_data[0][$i] != $jieguo_data[1][$is]){
						$info_data[] = $jieguo_data[0][$i].'_'.$jieguo_data[1][$is];
					}
				}
			}
			$infos = implode('|', $info_data);
		}
		return $infos;
	}
	
	public function format_info2($info, $num = 4, $fenge = '<br>'){
		$infos = '';
		if(!empty($info)){
			$info_data = array();
			$exp_info = explode("|", $info);
			foreach($exp_info as $k => $v){
				$exp_data = explode("_", $v);
				if(!empty($exp_data)){
					foreach($exp_data as $ek => $ev){
						$exp_data1 = explode(",", $ev);
						$jieguo_data[$k][] = $exp_data1;
					}
				}
			}
			$info_list = array();
			foreach($jieguo_data as $k => $v){
				for($i = 0; $i < count($v[0]); $i++){
					for($is = 0; $is < count($v[1]); $is++){
						if($v[0][$i] != $v[1][$is]){
							$info_data[] = '冠军：'.str_pad($v[0][$i],2,"0",STR_PAD_LEFT).' 亚军：'.str_pad($v[1][$is],2,"0",STR_PAD_LEFT);
						}
					}
				}
			}
			if(count($info_data) >= 15){
				$format_list = $info_data;
				unset($info_data);
				$linshi_array = array();
				for($i = 1; $i <= count($format_list); $i++){
					$linshi_array[] = $format_list[$i-1];
					if($i%$num == 0){
						$info_data[] = implode("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $linshi_array);
						$linshi_array = array();
					}
				}
			}
			$infos = implode($fenge, $info_data);
		}
		return $infos;
	}
	
	//游戏1玩法1注数计算
	public function game1_zhushu1($info){
		$zhushu = 0;
		if(!empty($info)){
			//区分多组
			$exp_info = explode("|", $info);
			//print_r($exp_info);exit;
			if(!empty($exp_info)){
				foreach($exp_info as $k => $v){
					//分道
					$exp_info1 = explode("_", $v);
					if(count($exp_info1) > 10){
						return -1;//格式错误
					}else if(!empty($exp_info1)){
						foreach($exp_info1 as $k1 => $v1){
							$exp_info2 = explode(",", $v1);
							if(!empty($exp_info2)){
								foreach($exp_info2 as $k2 => $v2){
									if(intval($v2) >= 1){
										$zhushu += 1;
									}
								}
							}
						}
					}
				}
			}
		}
		return $zhushu;
	}
	
	//游戏1玩法2注数计算
	public function game1_zhushu2($info){
		$zhushu = 0;
		$data0 = $data1 = array();
		if(!empty($info)){
			//区分多组
			$exp_info = explode("|", $info);
			//print_r($exp_info);exit;
			if(!empty($exp_info)){
				foreach($exp_info as $k => $v){
					//分道
					$exp_info1 = explode("_", $v);
					if(count($exp_info1) > 2){
						return -1;//格式错误
					}else if(!empty($exp_info1)){
						if(!empty($exp_info1[0])){
							$exp_info1_1 = explode(",", $exp_info1[0]);
							foreach($exp_info1_1 as $k => $v){
								$data0[$v] = 1;
							}
						}
						if(!empty($exp_info1[1])){
							$exp_info1_2 = explode(",", $exp_info1[1]);
							foreach($exp_info1_2 as $k => $v){
								$data1[$v] = 1;
							}
						}
						if(!empty($data0) and !empty($data1)){
							foreach($data0 as $k => $v){
								foreach($data1 as $k1 => $v1){
									if($k != $k1){
										$zhushu += 1;
									}
								}
							}
						}
					}
				}
			}
		}
		return $zhushu;
	}
}
?>