<?php
class userbankcard extends base_model{
	function __construct() {
		parent::__construct();
		$this->table = 'userbankcard';
		$this->primarykey = array('id');
		$this->maxcol = 'id';
	}
	
	public function create($arr) {
		$arr['id'] = $this->add($arr);
		if($arr['id'] >= 1) {
			return $arr['id'];
		} else {
			return 0;
		}
	}
	
	public function create1($arr) {
		empty($arr['id']) && $arr['id'] = $this->maxid('+1');
		if($this->set($arr['id'], $arr)) {
			$this->count('+1');
			return $arr['id'];
		} else {
			$this->maxid('-1');
			return 0;
		}
	}
	
	public function update($uid, $arr) {
		return $this->set($uid, $arr);
	}
	
	public function read($uid) {
		return $this->get($uid);
	}

	public function _delete($uid) {
		$return = $this->delete($uid);
		if($return) {
			$this->count('-1');
		}
		return $return;
	}

	public function bank_type() {
		$return = array(
			1 => '农业银行',
			2 => '中国银行',
			3 => '建设银行',
			4 => '光大银行',
			5 => '兴业银行',
			6 => '中信银行',
			7 => '工商银行',
			8 => '邮政储蓄',
			9 => '招商银行',
			10 => '平安银行',
		);
		return $return;
	}
}
?>