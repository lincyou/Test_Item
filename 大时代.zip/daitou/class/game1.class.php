<?php
class game1 extends base_model{
	var $haoma = '';
	var $jieguo = array();

	function __construct() {
		parent::__construct();
	}
	
	//格式化开奖号码并处理为校对格式
	public function haoma($haoma){
		if(!empty($haoma)){
			$this->haoma = $haoma;
			$jieguo_data = array();
			$exp_jieguo = explode(",", $haoma);
			$jieguo_data[1] = $exp_jieguo;
			if(!empty($exp_jieguo[0]) and !empty($exp_jieguo[1])){
				$jieguo_data[2] = intval($exp_jieguo[0]).'_'.intval($exp_jieguo[1]);
			}
			$this->jieguo = $jieguo_data;
		}
	}
	
	public function open_wanfa1($info){
		$num = 0;
		if(!empty($info)){
			$info_data = $jieguo_data = array();
			$exp_info = explode("|", $info);
			foreach($exp_info as $k => $v){
				$exp_data = explode("_", $v);
				if(!empty($exp_data)){
					foreach($exp_data as $ek => $ev){
						$exp_data1 = explode(",", $ev);
						$jieguo_data[] = $exp_data1;
					}
				}
			}
			if(!empty($jieguo_data)){
				foreach($jieguo_data as $k => $v){
					foreach($v as $ak => $av){
						if($av == $this->jieguo[1][$k]){
							$num += 1;
						}
					}
				}
			}
		}
		//print_r($this->jieguo);
		//print_r($jieguo_data);
		return $num;//中奖注数
	}
	
	public function open_wanfa2($info){
		if(!empty($info)){
			$info_data = array();
			$exp_info = explode("|", $info);
			foreach($exp_info as $k => $v){
				$exp_data = explode("_", $v);
				if(!empty($exp_data)){
					foreach($exp_data as $ek => $ev){
						$exp_data1 = explode(",", $ev);
						$jieguo_data[$k][] = $exp_data1;
					}
				}
			}
			$info_list = array();
			foreach($jieguo_data as $k => $v){
				for($i = 0; $i < count($v[0]); $i++){
					for($is = 0; $is < count($v[1]); $is++){
						if(intval($v[0][$i]) != intval($v[1][$is])){
							if(empty($info_list[intval($v[0][$i]).'_'.intval($v[1][$is])])){
								$info_list[intval($v[0][$i]).'_'.intval($v[1][$is])] = 1;
							}else{
								$info_list[intval($v[0][$i]).'_'.intval($v[1][$is])] += 1;
							}
						}
					}
				}
			}
			if(!empty($info_list[$this->jieguo[2]])){
				return $info_list[$this->jieguo[2]];//中奖一注
			}
		}
		return 0;//未中奖
	}
}
?>