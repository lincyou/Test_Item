<?php
//初始化数据文件
class loaddata{
	function __construct() {
		$day_num = 1;
		$jiatime = 0;
		if(!empty($day_num)){
			$jiatime = 86400 * $day_num;
		}
		$this->starttime = strtotime(date("Ymd", $_SERVER['time']))+$jiatime;
		$this->fengtime = 0;//封盘比开奖提前多少秒
	}

	//获得所有初始化数据
	public function gamedata(){
		$datas = array();
		$data_list = array(1);
		foreach($data_list as $k => $v){
			$data = array();
			$f_name = 'game'.$v;
			$dataa = $this->$f_name();
			for($i = 0; $i < count($dataa); $i++){
				$datas[] = $dataa[$i];
			}
		}
		//print_r($datas);exit;
		return $datas;
	}

	//北京赛车初始化数据
	public function game1(){
		$data = array();
		$start_id = 689474;
		$start_time = strtotime('2018-06-26');
		$num = 179;
		$day_start_id = (intval(($this->starttime - $start_time) / 86400) * $num) + $start_id;
		for($i = 1; $i <= $num; $i++){
			$open_time = $this->starttime + 32400 + $i * 300;
			$qihao = $day_start_id + $i;
			$data[] = array(
				'qihao' => $qihao,
				'open_time' => $open_time,
				'feng_time' => $open_time - $this->fengtime,
				'gameid' => 1,
			);
		}
		return $data;
	}
}
?>