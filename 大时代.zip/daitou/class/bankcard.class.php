<?php
class bankcard extends base_model{
	function __construct() {
		parent::__construct();
		$this->table = 'bankcard';
		$this->primarykey = array('id');
		$this->maxcol = 'id';
	}
	
	public function create($arr) {
		$arr['id'] = $this->add($arr);
		if($arr['id'] >= 1) {
			return $arr['id'];
		} else {
			return 0;
		}
	}
	
	public function create1($arr) {
		empty($arr['id']) && $arr['id'] = $this->maxid('+1');
		if($this->set($arr['id'], $arr)) {
			$this->count('+1');
			return $arr['id'];
		} else {
			$this->maxid('-1');
			return 0;
		}
	}
	
	public function update($uid, $arr) {
		return $this->set($uid, $arr);
	}
	
	public function read($uid) {
		return $this->get($uid);
	}

	public function _delete($uid) {
		$return = $this->delete($uid);
		if($return) {
			$this->count('-1');
		}
		return $return;
	}

	public function bank_name(){
		$return = array(
			1 => '银行转账',
			2 => '支付宝',
			3 => '微信支付',
		);
		return $return;
	}

	public function user_type(){
		$return = array(
			1 => '会员',
			2 => '代理',
			3 => '总代理',
			4 => '股东',
		);
		return $return;
	}

	public function stuat(){
		$return = array(
			1 => '启用',
			2 => '停用',
		);
		return $return;
	}
}
?>