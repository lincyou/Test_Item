<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');

include BBS_PATH.'control/common_control.class.php';

class pk10_control extends common_control {
	
	function __construct() {
		parent::__construct();
		$this->typeid = 1;//游戏ID
		$this->game_name = '北京赛车';
		$shi = date("H", $_SERVER['time']);
		$fen = date("i", $_SERVER['time']);
		if($shi >= 1 and $shi < 9){
			$this->on_echo(" ".$this->game_name."1-9点不采集\r\n");
			exit;
		}
	}

	//采集数据
	public function on_pk10data(){
		//采集源ID = 1
		$yid = 1;
		$up_stuat = 0;
		$intdate = date("Ymd", $_SERVER['time']);
		$date = date("m-d H:i:s", $_SERVER['time']);
		$this->on_echo(" ".$date."进行".$this->game_name."采集接口1\r\n");
		//$urldate = date("Y-m-d", $_SERVER['time']);
		$cache = $this->mcache->read('caiji');
		if(!empty($cache[$this->typeid])){
			$qidate = substr($cache[$this->typeid], 0, 8);
			$num = substr($cache[$this->typeid], 8, 3);
			$qidate_info = strtotime(substr($cache[$this->typeid], 0, 4).'-'.substr($cache[$this->typeid], 4, 2).'-'.substr($cache[$this->typeid], 6, 2));
			if($qidate < $intdate){
				if($num == 179){
					$data_time = $qidate_info + 86400;
					$urldate = date("Y-m-d", $data_time);
				}else{
					$urldate = date("Y-m-d", $qidate_info);
				}
			}else{
				$urldate = date("Y-m-d", $_SERVER['time']);
			}
		}else{
			$cache[$this->typeid] = 710596;
			$urldate = date("Y-m-d", $_SERVER['time']);
		}
		$url = "https://m.600w5.com/ssc/ajaxGetDataHistory.json?timestamp=".$_SERVER['time'].rand(100, 999);
		$post = array(
			'pageIndex' => 1,
			'pageSize' => '200',
			'openDate' => '',//开奖时间
			'number' => '',
			'playGroupId' => 9,
			'startTime' => '',
			'endTime' => '',
		);
		//print_r($post);
		$info = $this->za->post($url, $post);
		//print_r($info);exit;
		$data = json_decode($info, true);
		//print_r($data);exit;
		if(!empty($data['result'])){
			$this->c('kaijiang');
			$new = '';
			$data_list = $post_data = array();
			$end_qihao = $cache[$this->typeid];
			asort($data['sscHistoryList']);
			//print_r($data);exit;
			foreach($data['sscHistoryList'] as $k => $v){
				if($v['number'] > $end_qihao){
					$info = $this->kaijiang->get_info_by_qihao($v['number'], $this->typeid);
					if(!empty($info) and $info['stuat'] == 0){
						if(!empty($v['openCode'])){
							$exp_haoma = explode(",", $v['openCode']);
							foreach($exp_haoma as $haoma_k => $haoma_v){
								$exp_haoma[$haoma_k] = intval($haoma_v);
							}
						}
						$info['haoma'] = $v['openCode'];
						$info['stuat'] = 1;
						$info['open_time'] = $v['openTime']/1000;
						//$info['']
						$this->kaijiang->update($info['id'], $info);
						$up_stuat = 1;
						$end_qihao = $v['number'];
						$new .= " ".$v['number'].":".$v['openCode']."\r\n";
					}
				}
			}
			if($up_stuat == 1){
				$end_data = $this->get_end_qihao(1);
				$beitou_info = $this->game_beitou(1);
				$end_data['bet1'] = $beitou_info['bet1'];
				$end_data['bet2'] = $beitou_info['bet2'];
				$end_data['bet3'] = $beitou_info['bet3'];
				$end_data['bet1_num'] = $beitou_info['bet1_num'];
				$end_data['bet2_num'] = $beitou_info['bet2_num'];
				$end_data['bet3_num'] = $beitou_info['bet3_num'];
				$this->kaijiang->update($end_data['id'], $end_data);
				$this->up_caipiao_cache();
			}
			$new .= " ".$this->game_name."最后一期期号：".$end_qihao;
			//print_r($data_list);exit;
			$this->on_echo($new);
		}else{
			$this->on_echo(" ".$date."无法采集".$this->game_name."数据");
		}
	}

	//采集数据
	public function on_pk10data1(){
		//采集源ID = 1
		$yid = 1;
		$up_stuat = 0;
		$intdate = date("Ymd", $_SERVER['time']);
		$date = date("m-d H:i:s", $_SERVER['time']);
		$this->on_echo(" ".$date."进行".$this->game_name."采集接口2\r\n");
		//$urldate = date("Y-m-d", $_SERVER['time']);
		$cache = $this->mcache->read('caiji');
		if(!empty($cache[$this->typeid])){
			$qidate = substr($cache[$this->typeid], 0, 8);
			$num = substr($cache[$this->typeid], 8, 3);
			$qidate_info = strtotime(substr($cache[$this->typeid], 0, 4).'-'.substr($cache[$this->typeid], 4, 2).'-'.substr($cache[$this->typeid], 6, 2));
			if($qidate < $intdate){
				if($num == 179){
					$data_time = $qidate_info + 86400;
					$urldate = date("Y-m-d", $data_time);
				}else{
					$urldate = date("Y-m-d", $qidate_info);
				}
			}else{
				$urldate = date("Y-m-d", $_SERVER['time']);
			}
		}else{
			$cache[$this->typeid] = 710596;
			$urldate = date("Y-m-d", $_SERVER['time']);
		}
		$url = "https://www.gm65.com/data/bjpk10/lotteryList/2018-11-08.json";
		//print_r($post);
		$info = $this->za->curlPost($url);
		//print_r($info);exit;
		$data = json_decode($info, true);
		//print_r($data);exit;
		if(!empty($data['result'])){
			$this->c('kaijiang');
			$new = '';
			$data_list = $post_data = array();
			$end_qihao = $cache[$this->typeid];
			asort($data['sscHistoryList']);
			//print_r($data);exit;
			foreach($data['sscHistoryList'] as $k => $v){
				if($v['number'] > $end_qihao){
					$info = $this->kaijiang->get_info_by_qihao($v['number'], $this->typeid);
					if(!empty($info) and $info['stuat'] == 0){
						if(!empty($v['openCode'])){
							$exp_haoma = explode(",", $v['openCode']);
							foreach($exp_haoma as $haoma_k => $haoma_v){
								$exp_haoma[$haoma_k] = intval($haoma_v);
							}
						}
						$info['haoma'] = $v['openCode'];
						$info['stuat'] = 1;
						$info['open_time'] = $v['openTime']/1000;
						//$info['']
						$this->kaijiang->update($info['id'], $info);
						$up_stuat = 1;
						$end_qihao = $v['number'];
						$new .= " ".$v['number'].":".$v['openCode']."\r\n";
					}
				}
			}
			if($up_stuat == 1){
				$end_data = $this->get_end_qihao(1);
				$beitou_info = $this->game_beitou(1);
				$end_data['bet1'] = $beitou_info['bet1'];
				$end_data['bet2'] = $beitou_info['bet2'];
				$end_data['bet3'] = $beitou_info['bet3'];
				$end_data['bet1_num'] = $beitou_info['bet1_num'];
				$end_data['bet2_num'] = $beitou_info['bet2_num'];
				$end_data['bet3_num'] = $beitou_info['bet3_num'];
				$this->kaijiang->update($end_data['id'], $end_data);
				$this->up_caipiao_cache();
			}
			$new .= " ".$this->game_name."最后一期期号：".$end_qihao;
			//print_r($data_list);exit;
			$this->on_echo($new);
		}else{
			$this->on_echo(" ".$date."无法采集".$this->game_name."数据");
		}
	}
}
?>