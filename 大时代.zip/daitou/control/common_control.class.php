<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');

class common_control extends base_control {
	
	// 为了避免与 model 冲突，加下划线分开
	public $_sid = '';		// session id
	public $_user = array();	// 全局 user
	public $_class_list = array();	// 全局 class_list
	public $_admin = array();	// 全局 admin
	public $_dev = array();	// 全局 dev
	public $admin_system = array();	// 全局 admin_system
	
	// header 相关
	public $_title = array();	// header.htm title
	public $_nav = array();		// header.htm 导航
	public $_seo_keywords = '';	// header.htm keywords
	public $_seo_description = '';	// header.htm description
	public $_checked = array();	// 选中状态
	
	// 计划任务
	protected $_cron_1_run = 0;	// 计划任务1 是否被激活, 15 分钟执行一次
	protected $_cron_2_run = 0;	// 计划任务2 是否被激活, 每天0点执行一次
	
	// hook common_control_before.php
	
	// 初始化 _sid, _user, _title, _nav
	function __construct() {
		// hook common_control_construct_before.php
		parent::__construct();
		// hook common_control_construct_after.php
		
		$this->init_open();
		$this->init_timezone();
		//$this->conf['runtime'] = &$this->runtime->read_site();	// 析构函数会比 mysql 的析构函数早。所以不用担心mysql被释放。
                	
		//$this->check_lang();
		$this->init_view();
		//$this->init_sid();
		$this->init_user();
		$this->init_admin();
		$this->check_ip();
		//$this->check_safecode();
		//$this->check_domain();
		$this->init_cron();
		//$this->check_msg();
		// hook common_control_init_after.php
	}
	
	//判断网站打开
	private function init_open() {
		if($this->conf['open_stuat'] == 2){
			echo $this->conf['close_info'];
			exit;
		}
	}
	
	private function init_timezone() {
		// 不需要设置，使用gmdate()
		$offset = $this->conf['timeoffset'];
		if($offset) {
			date_default_timezone_set('Etc/GMT'.$offset);
		}
		
		// 今日凌晨0点的开始时间！
		$_SERVER['time_fmt'] = gmdate('Y-n-d H:i', $_SERVER['time'] + $offset * 3600);			// +8 hours
		$arr = explode(' ', $_SERVER['time_fmt']);
		list($y, $n, $d) = explode('-', $arr[0]);
		$_SERVER['time_today'] = gmmktime(0, 0, 0, $n, $d, $y) - $offset * 3600;	// -8 hours
		
		// hook common_control_init_timezone_after.php
	}
	
	private function init_view() {
		//$keyword = "";
		//$keyword = core::gpc($keyword);
		$pagekeywords = $this->conf['seo_keywords'];
		$pagedescription = $this->conf['seo_description'];
		//$this->view->assign('keyword', $keyword);
		//print_r($lang);
		$this->view->assign('conf', $this->conf);
		$this->view->assign('_title', $this->_title);
		$this->view->assign('_nav', $this->_nav);
		$this->view->assign('pagekeywords', $pagekeywords);
		$this->view->assign('pagedescription', $pagedescription);
		$this->view->assign('seo_keywords', $this->_seo_keywords);
		$this->view->assign('seo_description', $this->_seo_description);
		$this->view->assign('_checked', $this->_checked);
		$this->view->assign('cron_1_run', $this->_cron_1_run);
		
		define('FORM_HASH', misc::form_hash($this->conf['public_key']));
		// hook common_control_init_view_after.php
	}
	
	// 初始化 sid
	private function init_sid() {
		$key = $this->conf['cookiepre'].'sid';
		$sid = core::gpc($key, 'R');
		if(!$sid) {
			$sid = substr(md5($_SERVER['REMOTE_ADDR'].rand(1, 2147483647)), 0, 16); // 兼容32,64位
			misc::set_cookie($key, $sid, $_SERVER['time'] + 86400 * 30, '/');
		}
		$this->_sid = $sid;
		$this->view->assign('_sid', $this->_sid);
		
		// hook common_control_init_sid_after.php
	}
	
	// 初始化 _user, 解密 cookie
	private function init_user() {
		$auth = core::gpc($this->conf['cookiepre'].'auth', 'R');
		$this->view->assign('_auth', $auth);
		$this->m('user');
		$this->_user = $this->user->decrypt_auth($auth);
		if($this->_user['id'] !=0){
			$this->_userdbinfo = $this->user->read($this->_user['id']);
			if(empty($this->_userdbinfo) or $this->_userdbinfo['login_time'] != $this->_user['login_time'] or $this->_userdbinfo['login_ip'] != $this->_user['ip']){
				ob_start();
				session_start();
				$error = array();
				$_SESSION['id'] = 0;
				misc::set_cookie($this->conf['cookiepre'].'auth', '', 0, '/');
				header("Location: ".$this->conf['app_url']);
				exit;
			}else{
				unset($this->_user['password']);
				if(!empty($this->_userdbinfo)){
					$this->_user = $this->_user + $this->_userdbinfo;
				}
				if(!empty($this->_userdbinfo) and $this->_userdbinfo['stuat'] == 2){
					ob_start();
					session_start();
					$error = array();
					$_SESSION['id'] = 0;
					misc::set_cookie($this->conf['cookiepre'].'auth', '', 0, '/');
					header("Location: ".$this->conf['app_url']);
					exit;
				}
			}
		}
		$_SERVER['miscarr'] = $this->mcache->read('miscarr');
		$this->view->assign('_user', $this->_user);
		//print_r($this->_user);
		//exit;
		// hook common_control_init_user_after.php
	}
	
	// 初始化 _admin, 解密 cookie
	private function init_admin() {
		$auth = core::gpc($this->conf['cookiepre'].'admin_auth', 'R');
		$this->view->assign('_admin_auth', $auth);
		$this->_admin = $this->admins->decrypt_auth($auth);
		if($this->_admin['id'] != 0){
			$admingroup = $this->mcache->read('admin', 'models', 'group_cache');
			$this->_admin = $this->admins->get($this->_admin['id']);
			unset($this->_admin['password']);
			unset($this->_admin['code']);
			$this->_admin['group'] = $admingroup[$this->_admin['groupid']];
			/*
			$this->_admindbinfo = $this->admins->read($this->_admin['id']);
			if(!empty($this->_admindbinfo)){
				$this->_admin = $this->_admin + $this->_admindbinfo;
				$admingroup = $this->mcache->read('admingroup');
				$system = explode("|", $admingroup[$this->_admindbinfo['groupid']]['system']);
				foreach($system as $k => $v){
					$admin_system[$v] = $v;
				}
				$this->_admin_system = $admin_system;
				$this->view->assign('admin_system', $admin_system);
			}
			*/
		}
		$this->view->assign('_admin', $this->_admin);
	}
	
	// 检查IP
	private function check_ip() {
		// IP 规则
		if($this->conf['iptable_on']) {
			$arr = include BBS_PATH.'conf/iptable.php';
			$blacklist = $arr['blacklist'];
			$whitelist = $arr['whitelist'];
			$ip = $_SERVER['REMOTE_ADDR'];
			if(!empty($blacklist)) {
				foreach($blacklist as $black) {
					if(substr($ip, 0, strlen($black)) == $black) {
						$this->message('对不起，您的IP ['.$ip.'] 已经被禁止，如果有疑问，请联系管理员。', 0);
					}
				}
			}
			if(!empty($whitelist)) {
				$ipaccess = FALSE;
				foreach($whitelist as $white) {
					if(substr($ip, 0, strlen($white)) == $white) {
						$ipaccess = TRUE;
						break;
					}
				}
				if(!$ipaccess) {
					$this->message('对不起，您的IP ['.$ip.'] 不允许访问，如果有疑问，请联系管理员。', 0);
				}
			}
		}
		
		// hook common_control_check_ip_after.php
	}

	//加载语言包
	private function check_lang() {
		$this->site_lang = "";
		$uri = $this->za->url_uri();
		if(empty($uri['lang'])){
			$this->site_lang = $lang = "cn";
		}else{
			$this->site_lang = $lang = $uri['lang'];
		}
		$langfile = BBS_PATH.'conf/'.$lang.'.php';
		if(!file_exists($langfile)){
			$langfile = BBS_PATH.'conf/cn.php';
		}
		include $langfile;
		$this->langs = $langs;
		$this->view->assign('site_lang', $this->site_lang);
		$this->view->assign('langs', $langs);
	}
	
	// 检查域名，如果不在安装域名下，跳转到安装域名。
	private function check_domain() {
		$appurl = $this->conf['app_url'];
		preg_match('#^http://([^/]+)/#', $appurl, $m);
		$installhost = $m[1];
		$installhosts = "api.".$m[1];
		$host = core::gpc('HTTP_HOST', 'S');
		if($host != $m[1] and $host != $installhosts) {
			$currurl = misc::get_script_uri();
			$newurl = preg_replace('#^http://([^/]+)/#', "http://$installhost/", $currurl);
			header("Location: $newurl");
			exit;
		}
	}
	
	private function init_cron() {
	}
	
	/*
	 * 功  能：
	 * 	提示单条信息
	 *  
	 * 用  法：
		 $this->message('站点维护中，请稍后访问！');
		$this->message('提交成功！', TRUE, '?forum-index-123.htm');
		$this->message('校验错误！', FALSE);
	 */
	public function message($message, $status = 1, $goto = '') {
		
		// hook common_control_message_before.php
		
		if(core::gpc('ajax', 'R')) {
			// 可能为窗口，也可能不为。
			$json = array('servererror'=>'', 'status'=>$status, 'message'=>$message);
			echo core::json_encode($json);
			exit;
		} else {
			$this->view->assign('message', $message);
			$this->view->assign('status', $status);
			$this->view->assign('goto', $goto);
			$this->view->display('message.htm');
			exit;
		}
	}
	
	/*
	 * 功  能：
	 * 	提示错误或者警告或者正常信息
	 *  
	 * 用  法：
		$error = array(
			'stuat' = 1,//状态，1为成功，2为失败，3为警告
			'info' = '充值成功！',//状态内容，例如：充值成功！
		);
		$this->error($error);
	 */
	public function error($error) {
		if($error['stuat'] == 1){
			$error['stuat'] = "success";
		}else if($error['stuat'] == 2){
			$error['stuat'] = "error";
		}else if($error['stuat'] == 3){
			$error['stuat'] = "warning";
		}else{
			$error['stuat'] = "error";
		}
		$this->view->assign('error', $error);
		$this->view->display('msg.htm');
		exit;
	}
	
	// relocation
	public function location($url) {
		header("Location: ".$url);
		exit;
	}
	
	public function form_submit() {
		// hook form_submit_after.php
		return misc::form_submit($this->conf['public_key']);
	}
	
	// --------------------------> 权限相关和公共的方法
	
	// 检查是否登录
	public function check_login() {
		ob_start();
		session_start();
		if(empty($this->_user['id'])) {
			$_SESSION['two_password'] = '';
			$url = "http://".core::gpc('HTTP_HOST', 'S').core::gpc('REQUEST_URI', 'S');
			echo "<script language='javascript'>top.location='".$this->conf['app_url']."index.html?lang=".$this->site_lang."';</script>";
			exit;
			header("Location: ".$this->conf['app_url']);
			exit;
			//$this->message('您还没有登录，请先登录。', -1); // .print_r($_COOKIE, 1)
		}
	}

	// 检查是否登录商户
	public function check_shoplogin() {
		ob_start();
		session_start();
		if(empty($this->_shopuser['id'])) {
			$url = "http://".core::gpc('HTTP_HOST', 'S').core::gpc('REQUEST_URI', 'S');
			echo "<script language='javascript'>top.location='".$this->conf['app_url']."shopmanage-index.htm';</script>";
			exit;
		}
	}

	// 检查是否输入二级密码
	public function check_twopassword() {
		if(empty($this->_user['id']) or empty($_SESSION['two_password']) or empty($this->_user['two_password']) or md5($this->_user['two_password']) != $_SESSION['two_password']) {
			$url = core::gpc('REQUEST_URI', 'S');
			header("Location: ".$this->conf['app_url']."member-twopassword.html?lang=".$this->site_lang."&purl=".urlencode($url));
			exit;
		}
	}

	// 检查管理员是否输入二级密码
	public function check_admintwopassword() {
		ob_start();
		session_start();
		if(empty($this->_admin['id']) or empty($_SESSION['admin_two_password']) or empty($this->_admin['two_password']) or md5($this->_admin['two_password']) != $_SESSION['admin_two_password']) {
			$url = core::gpc('REQUEST_URI', 'S');
			header("Location: ./?index-twopassword.htm?purl=".$url);
			exit;
		}
	}

	// 检查是否登录,登陸則返回首頁
	public function logincheck() {
		if(!empty($this->_user['id'])) {
			$url = "http://".core::gpc('HTTP_HOST', 'S').core::gpc('REQUEST_URI', 'S');
			header("Location: ".$this->conf['app_url']);
			exit;
			//$this->message('您还没有登录，请先登录。', -1); // .print_r($_COOKIE, 1)
		}
	}
	
	protected function check_user_exists($user) {
		if(empty($user)) {
			$this->message('用户不存在！可能已经被删除。', 0);
		}
	}
	
	// upload 相关，可能会给人偶然扫描到。todo: 安全性
	protected function get_aid_from_tmp($uid) {
		$file = $this->conf['tmp_path'].$uid.'_aids.tmp';
		if(!is_file($file)) {
			return array();
		}
		$aids = trim(file_get_contents($file));
		return explode(' ', $aids);
	}
	
	// upload 相关
	protected function clear_aid_from_tmp($uid) {
		$file = $this->conf['tmp_path'].$uid.'_aids.tmp';
		is_file($file) && unlink($file);
	}
	
	protected function check_user_delete($user) {
		if(empty($user)) {
			misc::set_cookie($this->conf['cookiepre'].'auth', '', 0, '/');
			$this->message('您的账户已经被删除。', 0);
		}
	}
	
	protected function check_adminlogin() {
		if(empty($this->_admin["id"])){
			header("location:./login.htm");
			exit;
		}
	}
	
	protected function check_editpassword() {
		//if(!empty($this->_user["id"]) and empty($this->_user["code"]) and !empty($_GET['n']) and $_GET['n'] != 'password' and $_GET['n'] != 'loginout'){
		if(empty($this->_user["code"])){
			header("location:./password.html");
			exit;
		}
	}
	
	protected function check_msg() {
		if(!empty($this->_admin["id"])){
			$msgstuat = $msgnum = 0;
			$systemmsg = $this->admins->systemmsg();
			if(count($systemmsg) >= 1){
				$msgnum = count($systemmsg);
				$msgstuat = 1;
			}
			$this->view->assign('systemmsg', $systemmsg);
			$this->view->assign('msgstuat', $msgstuat);
			$this->view->assign('msgnum', $msgnum);
		}
	}
	
	public function c($class = '') {
		if(!empty($class)) {
			$file = BBS_PATH.'class/'.$class.'.class.php';
			if(is_file($file)) {
				include_once $file;
				if(!empty($this->conf['shiwu']) and empty($this->_class_list[$class])){
					$this->_class_list[$class] = $_SERVER['time'];
				}
				$this->$class = new $class();
			}else{
				$this->$class = array();
			}
		}else{
			$this->$class = array();
		}
	}

	public function on_echo($info) {
		echo iconv("UTF-8", "GB2312//IGNORE", $info);
	}
	
	//更新全局缓存
	protected function up_caipiao_cache() {
		$this->c('kaijiang');
		$data_list = array();
		$data = $this->kaijiang->group(array('id' => array('>=' => 1), 'stuat' => 1), 'gameid', array('gameid', 'max(qihao) as qihaos'));
		if(!empty($data)){
			foreach($data as $k => $v){
				$data_list[$v['gameid']] = $v['qihaos'];
			}
			$add_cache = $this->mcache->diysave('caiji', $data_list);
		}
	}
	
	//计算倍投方案
	protected function game_beitou($gameid) {
		$this->c('kaijiang');
		$data_list = $beitou = $beitou_list1 = $beitou_list2 = $beitou_list3 = $saidao = array();
		for($i = 1; $i <= 10; $i++){
			$data_list[$i] = $this->beitou_load_data();
			$saidao[$i] = array();
		}
		$data2_list = $this->beitou_load_data(3, 19);
		$load_data = $data_list;//备份一个初始化数据
		$load_data2 = $data2_list;//备份一个初始化数据
		$beitou1_info = $beitou2_info = $beitou3_info = '';
		$data = $this->kaijiang->index_fetch(array('gameid' => $gameid, 'open_time' => array('<=' => $_SERVER['time'])), array('id' => 2), 0, 100);
		if(!empty($data)){
			$beitou1_num = $beitou2_num = $beitou3_num = 0;
			$money1_list = explode("\r\n", $this->conf['daitou_money']);
			$money1 = trim($money1_list[0]);
			$money2_list = explode("\r\n", $this->conf['daitou_money1']);
			$money2 = trim($money2_list[0]);
			asort($data);
			//print_r($data);
			foreach($data as $k => $v){
				if(!empty($v['haoma'])){
					$haoma = explode(',', $v['haoma']);
					foreach($haoma as $hk => $hv){
						$data_list[$hk+1] = $this->up_beitou_data($data_list[$hk+1], intval($hv));
					}
					//计算冠亚和值
					$data2_list = $this->up_beitou_data($data2_list, intval($haoma[0] + $haoma[1]));
				}else{
					$data_list = $load_data;
					$data2_list = $load_data2;
				}
			}
			//print_r($data2_list);exit;
			for($i = 1; $i <= 10; $i++){
				$wanfa1_data[$i] = $data_list[$i];
				arsort($wanfa1_data[$i]);
				$val_num = $del_array1 = 0;
				$val_i = array();
				//计算第一种算法倍投方案
				foreach($wanfa1_data[$i] as $k => $v){
					if($val_num < $this->conf['daitou_num_num']){
						if($v >= $this->conf['daitou_num']){
							$beitou[$i][] = $k;
							$val_i[] = $v;
							$val_num += 1;
						}
					}
					if($val_num == $this->conf['daitou_num'] + 1){
						if($val_i[$this->conf['daitou_num']] == $val_i[$this->conf['daitou_num'] - 1]){
							$del_array1 = 1;
						}
					}
				}
				if($val_num < $this->conf['daitou_num_num'] or $del_array1 == 1){
					$beitou_list1[$i] = '';
				}else{
					$beitou_list1[$i] = implode(",", $beitou[$i]);
					$beitou1_num += count($beitou[$i]);
				}
				$beitou1_info = implode("_", $beitou_list1);
				if($beitou1_info == '_________'){
					$beitou1_info = '';
					$beitou1_num = 0;
				}
				/*
				//计算第二种算法倍投方案
				for($is = 1; $is <= 10; $is++){
					if($data_list[$is][$i] >= $this->conf['daitou_num']){
						if(empty($saidao[$i][$is])){
							$saidao[$i][$is] = 1;
						}else{
							$saidao[$i][$is] += 1;
						}
					}
				}
				if(count($saidao[$i]) < $this->conf['daitou_num_num']){
					unset($saidao[$i]);
				}else{
					$beitou_list2[$i] = count($saidao[$i]);
				}
				*/
			}
			//计算第三种算法倍投方案
			//$this->conf['daitou_num1'] = 3;
			$beitou_fangan3 = 0;
			for($i = 1; $i <= 3; $i++){
				$group_haoma = explode(",", $this->conf['wanfa2_z'.$i]);
				$tou_stuat = 1;
				foreach($group_haoma as $k => $v){
					if($data2_list[$v] < $this->conf['daitou_num1']){
						$tou_stuat = 0;
					}
				}
				if($tou_stuat == 1){
					$beitou_list3[] = $this->conf['wanfa2_z'.$i];
					$beitou_fangan3 += 1;
					/*
					foreach($group_haoma as $k => $v){
						$beitou3 = $this->beitou3_make_data($v);
						if(!empty($beitou3)){
							$beitou_list3[] = implode("|", $beitou3);
						}
					}
					*/
				}else{
					$beitou_list3[] = '';
				}
			}
			if($beitou_fangan3 >= 1){
				$beitou3_num += count($beitou_list3);
				$beitou3_info = implode("_", $beitou_list3);
			}
			$list = array(
				'bet1' => $beitou1_info,
				'bet1_num' => $beitou1_num,
				'bet2' => $beitou2_info,
				'bet2_num' => $beitou2_num,
				'bet3' => $beitou3_info,
				'bet3_num' => $beitou3_num,
			);
			//print_r($list);
			return $list;
			/*
			print_r($beitou3_info);exit;
			//print_r($beitou_list2);
			print_r($data_list);exit;
			print_r($beitou_list);
			print_r($wanfa1_data);
			print_r($data_list);
			*/
		}
	}

	//投注函数
	function touzhu($data){
		$this->m('user');
		$user = $this->user->get($data['uid']);
		$total_money = $data['zhushu'] * $data['money'];
		if(empty($user)){
			return 4;//会员不存在
		}else if($user['yes_money'] < $total_money){
			return 3;//余额不足
		}else if($user['stuat'] != 1){
			return 2;//会员被冻结
		}else{
			//$lock = $this->lock->lock('user', $data['uid']);
			//if($lock == 1){
				$old_money = $user['yes_money'];
				$user['yes_money'] = $user['yes_money'] - $total_money;
				$user['no_money'] = $user['no_money'] - $total_money;
				if($user['no_money'] < 0){
					$user['no_money'] = 0;
				}
				$user['total_money'] = $user['total_money'] + $total_money;
				$user['day_yes_money'] = $user['day_yes_money'] + $total_money;
				$up_user = $this->user->update($user['id'], $user);
				if($up_user >= 1){
					$bet_data = array(
						'uid' => $data['uid'],
						'username' => $data['username'],
						'gameid' => $data['gameid'],
						'wanfa_id' => $data['wanfaid'],
						'infos' => $data['haoma'],
						'money' => $total_money,
						'jiangjin' => 0,
						'stuat' => 1,
						'typeid' => $data['typeid'],
						'qihao' => $data['qihao'],
						'qiid' => $data['qiid'],
						'agent_id' => $data['agent_id'],
						'add_time' => $_SERVER['time'],
						'dan_money' => $data['money'],
						'yingli_money' => 0,
						'zhuwei' => $data['zhuwei'],
					);
					$this->c('bet');
					$bet_data['id'] = $this->bet->create($bet_data);
					$moneylog_data = array(
						'uid' => $data['uid'],
						'username' => $data['username'],
						'money' => $total_money,
						'old_money' => $old_money,
						'add_time' => $_SERVER['time'],
						'typeid' => 2,
						'totypeid' => 3,
						'beizhu' => $bet_data['id'],
						'new_money' => $user['yes_money'],
					);
					//print_r($bet_data);
					$this->c('moneylog');
					$moneylog_data['id'] = $this->moneylog->create($moneylog_data);
					return 1;//投注成功
				}else{
					return 6;//会员被锁定
				}
				//$lock = $this->lock->unlock('user', $data['uid']);
			//}else{
			//	return 5;//会员被锁定
			//}
		}
	}

	//生成第三种算法的组合
	function beitou3_make_data($number){
		$data = array(
			3 => array('1_2', '2_1'),
			4 => array('1_3', '3_1'),
			5 => array('1_4', '2_3', '3_2', '4_1'),
			6 => array('1_5', '2_4', '4_2', '5_1'),
			7 => array('1_6', '2_5', '3_4', '4_3', '5_2', '6_1'),
			8 => array('1_7', '2_6', '3_5', '5_3', '6_2', '7_1'),
			9 => array('1_8', '2_7', '3_6', '4_5', '5_4', '6_3', '7_2', '8_1'),
			10 => array('1_9', '2_8', '3_7', '4_6', '6_4', '7_3', '8_2', '9_1'),
			11 => array('1_10', '2_9', '3_8', '4_7', '5_6', '6_5', '7_4', '8_3', '9_2', '10_1'),
			12 => array('2_10', '3_9', '4_8', '5_7', '7_5', '8_4', '9_3', '10_2'),
			13 => array('3_10', '4_9', '5_8', '6_7', '7_6', '8_5', '9_4', '10_3'),
			14 => array('4_10', '5_9', '6_8', '8_6', '9_5', '10_4'),
			15 => array('5_10', '6_9', '7_8', '8_7', '9_6', '10_5'),
			16 => array('6_10', '7_9', '9_7', '10_6'),
			17 => array('7_10', '8_9', '9_8', '10_7'),
			18 => array('8_10', '10_8'),
			19 => array('9_10', '10_9'),
		);
		if(!empty($data[$number])){
			return $data[$number];
		}else{
			return array();
		}
	}

	//查询最新期号
	public function get_end_qihao($gameid){
		$info = array();
		$this->c('kaijiang');
		$data = $this->kaijiang->index_fetch(array('gameid' => $gameid, 'open_time' => array('>=' => $_SERVER['time'])), array('open_time' => 1), 0, 1);
		if(!empty($data)){
			list($k, $info) = each($data);
		}
		return $info;
	}

	//初始化投注数据
	public function bet_load_data($start = 1, $end = 10){
		$data = array();
		for($i = $start; $i <= $end; $i++){
			$data[$i] = '';
		}
		return $data;
	}

	//初始化数据
	public function beitou_load_data($start = 1, $end = 10){
		$data = array();
		for($i = $start; $i <= $end; $i++){
			$data[$i] = 0;
		}
		return $data;
	}

	//更新计数数据
	public function up_beitou_data($data, $number){
		foreach($data as $k => $v){
			if($k == $number){
				$data[$k] = 0;
			}else{
				$data[$k] = $data[$k] + 1;
			}
		}
		//echo $number;
		//print_r($data);exit;
		return $data;
	}
	
	public function m($models = '', $model = 'model') {
		if($model == 'model'){
			$class_name = $models;
		}else{
			$class_name = $model;
		}
		if(!empty($this->conf['shiwu']) and empty($this->_class_list[$class_name])){
			$this->_class_list[$class_name] = $_SERVER['time'];
		}
		$this->$class_name = $this->mcache->m($models, $model);
	}
	
	// 开始事务模式
	public function shiwu_start(){
		if(empty($this->conf['shiwu'])){
			throw new Exception('未开启事务模式！');
		}else if($this->conf['shiwu'] == 2){
			//$shiwu_sql1 = "start transaction";
			//$query_sql1 = $this->za->mysqlquery( $shiwu_sql1 );
			$shiwu_sql3 = "BEGIN";
			$query_sql3 = $this->za->mysqlquery( $shiwu_sql3 );
			$shiwu_sql2 = "SET AUTOCOMMIT=0";
			$query_sql2 = $this->za->mysqlquery( $shiwu_sql2 );
		}
	}
	
	// 事务保存
	public function shiwu_ok(){
		if(empty($this->conf['shiwu'])){
			throw new Exception('未开启事务模式！');
		}else if($this->conf['shiwu'] == 2){
			$shiwu_sql2 = "COMMIT";
			$query_sql2 = $this->za->mysqlquery( $shiwu_sql2 );
			$shiwu_sql1 = "SET AUTOCOMMIT=1";
			$query_sql1 = $this->za->mysqlquery( $shiwu_sql1 );
		}
	}
	
	// 事务退回
	public function shiwu_back(){
		if(empty($this->conf['shiwu'])){
			throw new Exception('未开启事务模式！');
		}else if($this->conf['shiwu'] == 2){
			$shiwu_sql2 = "ROLLBACK";
			$query_sql2 = $this->za->mysqlquery( $shiwu_sql2 );
			$shiwu_sql1 = "SET AUTOCOMMIT=1";
			$query_sql1 = $this->za->mysqlquery( $shiwu_sql1 );
		}else{
			//$db = $this->moneylog->get(2);
			//echo "888";print_r($db);
			print_r($this->_class_list);
		}
	}
	
	/*
	//用户锁，防止用户多次读取修改导致数据错误使用，不一定保证绝对唯一，但是防止一部分情况的重复，要害更新最好使用update检测
	public function lock_user($uid){
		//防止意外死锁，执行时间只给30秒，超时前也够用了
		set_time_limit(30);
		if($this->conf['lock_type'] == 1){
			//暂时不考虑使用memcache锁
		}else if($this->conf['lock_type'] == 2){
			//MYSQL内存表锁
			$this->m("user", "lock");
			$handle_type = 1;//重复请求的三种处理方式，1=只处理第一条其他抛弃，2=全部处理，3=全部抛弃
			$lock_stuat = $this->lock->total(array('uid' => $uid));
			if($lock_stuat == 0 or $handle_type == 2){
				$lock_data = array(
					'uid' => $uid,
					'add_time' => time(),
				);
				$lock_id = $this->lock->create($lock_data);
				if($lock_id >= 1){
					//延迟0.3秒防止入库中的数据没有被查询到
					usleep(300000);
					$lock_top_id = $this->get_lock_user($uid);
					echo $lock_id."|||".$lock_top_id."|||";
					if($handle_type == 1){
						if($lock_top_id == $lock_id){
							echo $lock_top_id."||";
							return 1;
						}else{
							$this->lock->_delete($lock_id);
							return 2;//不需处理数据，抛弃
						}
					}else if($handle_type == 2){
						return 1;
					}else{
						$this->lock->_delete($lock_id);
						return 2;//全部不处理数据，抛弃
					}
				}else{
					usleep(rand(300000, 1000000));
					return $this->lock_user($uid);
				}
			}else if($handle_type == 1){
				//只处理第一条，其他抛弃
				return -1;//抛弃处理
			}else if($handle_type == 3){
				return -1;//全部抛弃
			}else{
				sleep(rand(300000, 1000000));
				return $this->lock_user($uid);
			}
		}else{
			$file = $this->conf['lock_path'].'user-'.$uid.'.txt';
			if(file_exists($file)){
				//使用随机间隔防止冲突
				sleep(rand(500000, 2000000));
				return $this->lock_user($uid);
			}else{
				//使用追加方式追加，这样判断文件大小也可以知道同时的请求有多少
				file_put_contents($file, "1", FILE_APPEND);
				return $this->get_lock_user($uid);
			}
		}
	}

	//获得用户锁的同时处理事务数，不包括等待中的事务请求
	public function get_lock_user($uid){
		if($this->conf['lock_type'] == 1){
			//暂时不考虑使用memcache锁
		}else if($this->conf['lock_type'] == 2){
			//MYSQL内存表锁
			$this->m("user", "lock");
			$lock_list = $this->lock->index_fetch(array('uid' => $uid), array('id' => 1), 0, 1);
			list($k, $v) = each($lock_list);
			return $v['id'];
		}else{
			//文件锁
			$file = $this->conf['lock_path'].'user-'.$uid.'.txt';
			if(file_exists($file)){
				return filesize($file);
			}else{
				return 0;
			}
		}
	}

	//解锁用户锁
	public function unlock_user($uid){
		set_time_limit(0);
		if($this->conf['lock_type'] == 1){
			//暂时不考虑使用memcache锁
		}else if($this->conf['lock_type'] == 2){
			//MYSQL内存表锁
			$this->m("user", "lock");
			$lock_list = $this->lock->index_fetch(array('uid' => $uid), array('id' => 1), 0, 1000);
			if(count($lock_list) >= 1){
				foreach($lock_list as $k => $v){
					$this->lock->_delete($v['id']);
				}
			}
			return 1;
		}else{
			//文件锁
			$file = $this->conf['lock_path'].'user-'.$uid.'.txt';
			if(file_exists($file)){
				//删除锁文件
				unlink($file);
				return 1;
			}else{
				//没有锁存在
				return 2;
			}
		}
	}
	*/
}

// hook common_control_after.php

?>