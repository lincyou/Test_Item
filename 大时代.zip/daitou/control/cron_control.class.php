<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');

include BBS_PATH.'control/common_control.class.php';

class cron_control extends common_control {
	
	function __construct() {
		parent::__construct();
		$this->cron_files = BBS_PATH.'models';
		$this->lockfile = $this->conf['tmp_path'].'cron.lock';
	}

	public function on_echo($info) {
		echo iconv("UTF-8", "GB2312//IGNORE", $info);
	}

	//设置任务运行标志
	public function add_cron_file() {
		file_put_contents($this->lockfile, '');
	}

	//删除任务运行标志
	public function del_cron_file() {
		unlink($this->lockfile);
	}

	//默认任务页面
	public function on_auto() {
		set_time_limit(0);
		$m = core::gpc('m', 'R');
		$time = core::gpc('time', 'R');
		if($_SERVER['SERVER_ADDR'] != $_SERVER['REMOTE_ADDR']){
			header('HTTP/1.1 404 Not Found');
			header("status: 404 Not Found");
			exit;
		}
		if($m == 'cron1' or $m == 'cron'){
			//header("Location: http://www.google.com");
			//exit;
			echo "456";
			exit;
		}
		if(empty($m)){
			$view_tmp = 'cron_index.htm';
		}else if($m == 'timer'){
			//定时器，定时搜索全部任务然后匹配对应增加
			$files = $cron_list = array();
			$handler = opendir($this->cron_files);
			$files = array();
			while (($filename = readdir($handler)) !== false) {//务必使用!==，防止目录下出现类似文件名“0”等情况
				if ($filename != "." and $filename != "..") {
					$files[] = $filename ;
				}
			}
			closedir($handler);
			//打印所有文件名
			if(!empty($files)){
				foreach($files as $value){
					$time = 3600;
					$cron_file = $this->cron_files.'/'.$value.'/cron.php';;
					if(is_file($cron_file)){
						$cron_config_file = $this->cron_files.'/'.$value.'/cron_config.php';
						if(is_file($cron_config_file)){
							include $cron_config_file;
						}
						$cron_list[] = $value."||".$time;
					}
				}
			}
			echo json_encode($cron_list);
			exit;
		}else{
			$cron_file = $this->cron_files.'/'.$m.'/cron.php';
			if(is_file($cron_file)){
				include $cron_file;
				$this->view->assign('models_name', $m);
				$this->view->assign('time', $time);
				$view_tmp = 'cron_info.htm';
			}else{
				header('HTTP/1.1 404 Not Found');
				header("status: 404 Not Found");
				exit;
			}
		}
		$this->view->display($view_tmp);
	}

	//默认任务页面
	public function on_auto_timer() {
	}

	//执行自动化任务脚本
	public function on_auto1() {
		set_time_limit(0);
		if(!is_file($this->lockfile)){
			$this->add_cron_file();
			$handler = opendir($this->cron_files);
			$files = array();
			while (($filename = readdir($handler)) !== false) {//务必使用!==，防止目录下出现类似文件名“0”等情况
				if ($filename != "." and $filename != "..") {
					$files[] = $filename ;
				}
			}
			closedir($handler);
			//打印所有文件名
			if(!empty($files)){
				foreach($files as $value){
					$cron_file = $this->cron_files.'/'.$value;
					if(is_file($cron_file)){
						include $cron_file;
					}
				}
			}
			$this->del_cron_file();
			$this->on_echo('全部任务完成！');
		}else{
			$this->on_echo('已有任务在运行，跳过本次运行！');
		}
	}
}
?>