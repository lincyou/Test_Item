<?php
// 后台配置，与前台配置基本一致，主要为模板相关
// model_path 可以为数组，会按照顺序搜索目录
return  array (
	'app_id' => 'siteadmin',
	'app_url' => $conf['app_url'],
	'admin_url' => $conf['app_url'].ADMIN_PATH.'/',
	'control_path' => array(BBS_PATH.ADMIN_PATH.'/control/'),
	'view_path' => array(BBS_PATH.ADMIN_PATH.'/view/'),
	'menu' => array(
		'platform' => array(
			'id' => 1, 'name' => '运营管理', 'ico' => 'no', 'files' => 'platform', 'stuat' => 1, 'page' => '#', 'down' =>array(
				array('id' => '1-1', 'name'=>'会员', 'ico' => 'ico-system-1', 'files' => 'usermanage', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '1-1-1', 'name'=>'会员管理', 'ico' => 'ico-system-1', 'files' => 'manage', 'stuat' => 1, 'page' => './models.php?m=user&n=manage','system' => array('1-1-1-1' => '查看列表','1-1-1-2' => '编辑会员','1-1-1-3' => '导出资料',),),
						array('id' => '1-1-3', 'name'=>'会员帐变记录', 'ico' => 'ico-system-1', 'files' => 'changemoney', 'stuat' => 1, 'page' => './models.php?m=user&n=changemoney','system' => array('1-1-3-1' => '查看帐变列表','1-1-3-2' => '导出帐变信息','1-1-3-3' => '修改帐变记录',),),
						array('id' => '1-1-4', 'name'=>'资金增减', 'ico' => 'ico-system-1', 'files' => 'money', 'stuat' => 1, 'page' => './models.php?m=user&n=money','system' => array('1-1-4-1' => '增减会员资金',),),
						//array('id' => '1-1-6', 'name'=>'积分增减记录', 'ico' => 'ico-system-1', 'files' => 'systemmoneylog', 'stuat' => 1, 'page' => './models.php?m=user&n=systemmoneylog','system' => array('1-1-6-1' => '查看数据',),),
						//array('id' => '1-1-5', 'name'=>'任务记录', 'ico' => 'ico-system-1', 'files' => 'task', 'stuat' => 1, 'page' => './models.php?m=user&n=tasklist','system' => array('1-1-5-1' => '查看数据',),),
					),
				),
				array('id' => '1-2', 'name'=>'资金管理', 'ico' => 'ico-shop-4', 'files' => 'user', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '1-2-1', 'name'=>'入款管理', 'ico' => 'ico-shop-4', 'files' => 'in_money_list', 'stuat' => 1, 'page' => './models.php?m=user&n=in_money_list','system' => array('1-2-1-1' => '查看列表','1-2-1-2' => '审核入款',),),
						array('id' => '1-2-2', 'name'=>'出款管理', 'ico' => 'ico-shop-4', 'files' => 'out_money_list', 'stuat' => 1, 'page' => './models.php?m=user&n=out_money_list','system' => array('1-2-2-1' => '查看列表','1-2-2-2' => '审核出款',),),
						array('id' => '1-2-3', 'name'=>'收款方式管理', 'ico' => 'ico-shop-4', 'files' => 'bankcard_list', 'stuat' => 1, 'page' => './models.php?m=user&n=bankcard_list','system' => array('1-2-3-1' => '查看列表','1-2-3-2' => '增加收款方式','1-2-3-3' => '编辑收款方式',),),
						array('id' => '1-2-4', 'name'=>'每日盈利记录', 'ico' => 'ico-shop-4', 'files' => 'totallog', 'stuat' => 1, 'page' => './models.php?m=user&n=totallog','system' => array('1-2-4-1' => '查看列表',),),
						array('id' => '1-2-5', 'name'=>'佣金审核', 'ico' => 'ico-shop-4', 'files' => 'yongjin', 'stuat' => 1, 'page' => './models.php?m=user&n=yongjin','system' => array('1-2-5-1' => '查看列表','1-2-5-2' => '审核佣金',),),
					),
				),
				array('id' => '1-3', 'name'=>'投注记录', 'ico' => 'ico-shop-3', 'files' => 'msg', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '1-3-1', 'name'=>'投注管理', 'ico' => 'ico-wx-1', 'files' => 'list', 'stuat' => 1, 'page' => './models.php?m=bet&n=list','system' => array('1-3-1-1' => '查看列表','1-3-1-2' => '撤销注单',),),
					),
				),
			),
		),
		'system' => array(
			'id' => 3, 'name' => '系统管理', 'ico' => 'no', 'files' => 'system', 'stuat' => 1, 'page' => '#', 'down' =>array(
				array('id' => '3-1', 'name'=>'管理员', 'ico' => 'ico-shop-3', 'files' => 'admin', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '3-1-1', 'name'=>'管理员管理', 'ico' => 'ico-system-1', 'files' => 'manage', 'stuat' => 1, 'page' => './models.php?m=admin&n=manage','system' => array('3-1-1-1' => '查看列表','3-1-1-2' => '增加管理员','3-1-1-3' => '编辑管理员',),),
						array('id' => '3-1-2', 'name'=>'管理员记录', 'ico' => 'ico-system-1', 'files' => 'log', 'stuat' => 1, 'page' => './models.php?m=admin&n=log','system' => array('3-1-2-1' => '查看记录',),),
						array('id' => '3-1-3', 'name'=>'管理组管理', 'ico' => 'ico-system-1', 'files' => 'groupmanage', 'stuat' => 1, 'page' => './models.php?m=admin&n=groupmanage','system' => array('3-1-3-1' => '查看列表','3-1-3-2' => '增加管理组','3-1-3-3' => '编辑管理组',),),
					),
				),
				array('id' => '3-2', 'name'=>'设置', 'ico' => 'ico-shop-0', 'files' => 'setting', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '3-2-1', 'name'=>'网站基本设置', 'ico' => 'ico-shop-0', 'files' => 'set', 'stuat' => 1, 'page' => './models.php?m=setting&n=set','system' => array('3-2-1-1' => '查看设置','3-2-1-2' => '修改设置',),),
						array('id' => '3-2-2', 'name'=>'网站开关', 'ico' => 'ico-shop-0', 'files' => 'open', 'stuat' => 1, 'page' => './models.php?m=setting&n=open','system' => array('3-2-2-1' => '查看设置','3-2-2-2' => '修改设置',),),
						array('id' => '3-2-3', 'name'=>'客户端设置', 'ico' => 'ico-shop-0', 'files' => 'client', 'stuat' => 1, 'page' => './models.php?m=setting&n=client','system' => array('3-2-3-1' => '查看设置','3-2-3-2' => '修改设置',),),
					),
				),
				array('id' => '3-4', 'name'=>'公告管理', 'ico' => 'ico-mobile-0', 'files' => 'notice', 'stuat' => 1, 'page' => '#', 'down' =>array(
						array('id' => '3-4-1', 'name'=>'公告管理', 'ico' => 'ico-shop-0', 'files' => 'notice', 'stuat' => 1, 'page' => './models.php?m=notice&n=list','system' => array('3-3-1-1' => '查看列表','3-3-1-2' => '增加公告','3-3-1-3' => '修改公告','3-3-1-4' => '删除公告',),),
					),
				),
			),
		),
	),
);

?>