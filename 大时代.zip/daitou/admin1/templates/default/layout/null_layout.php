<?php defined('In33hao') or exit('Access Invalid!');?>
<?php
require_once($tpl_file);
?>
