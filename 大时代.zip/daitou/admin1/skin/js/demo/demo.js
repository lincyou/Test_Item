$(document).ready(function() {
	/* Demo Start */
	
	/* jQuery-UI Widgets */
	
	$(".mws-accordion").accordion();
	
	$(".mws-tabs").tabs();
	
	$(".mws-datepicker").datepicker({showOtherMonths:true});
	
	$(".mws-datepicker-wk").datepicker({showOtherMonths:true, showWeek:true});
	
	$(".mws-datepicker-mm").datepicker({showOtherMonths:true, numberOfMonths:3});
	
	$(".mws-dtpicker").datetimepicker();
	
	$(".mws-tpicker").timepicker({});
	
	$(".mws-slider").slider({range: "min"});
	
	$(".mws-progressbar").progressbar({value: 37});
	
	$(".mws-range-slider").slider({range: true, min:0, max: 500, values: [75, 300]});
	
	var availableTags = [
		"ActionScript",
		"AppleScript",
		"Asp",
		"BASIC",
		"C",
		"C++",
		"Clojure",
		"COBOL",
		"ColdFusion",
		"Erlang",
		"Fortran",
		"Groovy",
		"Haskell",
		"Java",
		"JavaScript",
		"Lisp",
		"Perl",
		"PHP",
		"Python",
		"Ruby",
		"Scala",
		"Scheme"
	];
	$( ".mws-autocomplete" ).autocomplete({
		source: availableTags
	});
	
	$("#mws-jui-dialog").dialog({
		autoOpen: false, 
		title: "", 
		modal: true, 
		width: "640", 
		buttons: [{
				text: "关闭", 
				click: function() {
					$( this ).dialog( "close" );
				}}]
	});
	$("#mws-form-dialog").dialog({
		autoOpen: false, 
		title: $(this).attr('editurl'), 
		modal: true, 
		width: "640", 
		buttons: [{
				text: "递交", 
				click: function() {
					$( this ).find('form#mws-validate').submit();
				}}]
	});
	$("#mws-jui-dialog-btn").bind("click", function(event) {
		$("#mws-jui-dialog").dialog("option", {modal: false}).dialog("open");
		event.preventDefault();
	});
	$("#mws-jui-dialog-mdl-btn").bind("click", function(event) {
		$("#mws-jui-dialog").dialog("option", {modal: true}).dialog("open");
		event.preventDefault();
	});
	$("#mws-form-dialog-mdl-btn").bind("click", function(event) {
		$("#mws-form-dialog").dialog("option", {modal: true}).dialog("open");
		event.preventDefault();
	});
	
	$(".mws-slider-vertical").slider({
		orientation: "vertical", 
		range: "min",
		min: 0,
		max: 100,
		value: 60
	});
	
	$( "#eq > span" ).each(function() {
			// read initial values from markup and remove that
			var value = parseInt( $( this ).text(), 10 );
			$( this ).empty().slider({
				value: value,
				range: "min",
				animate: true, 
				orientation: "vertical"
			});
		});
	
	/* Spinner */
	
	var itemList = [
		{url: "http://ejohn.org", title: "John Resig"},
		{url: "http://bassistance.de/", title: "J&ouml;rn Zaefferer"},
		{url: "http://snook.ca/jonathan/", title: "Jonathan Snook"},
		{url: "http://rdworth.org/", title: "Richard Worth"},
		{url: "http://www.paulbakaus.com/", title: "Paul Bakaus"},
		{url: "http://www.yehudakatz.com/", title: "Yehuda Katz"},
		{url: "http://www.azarask.in/", title: "Aza Raskin"},
		{url: "http://www.karlswedberg.com/", title: "Karl Swedberg"},
		{url: "http://scottjehl.com/", title: "Scott Jehl"},
		{url: "http://jdsharp.us/", title: "Jonathan Sharp"},
		{url: "http://www.kevinhoyt.org/", title: "Kevin Hoyt"},
		{url: "http://www.codylindley.com/", title: "Cody Lindley"},
		{url: "http://malsup.com/jquery/", title: "Mike Alsup"}
	];
	
	var opts = {
		's1': {decimals:2},
		's2': {stepping: 0.25},
		's3': {currency: '$'}, 
		's4': {decimals:2}
	};

	for (var n in opts)
		$("#"+n).spinner();
	
	/* ColorPicker */
	
	$(".mws-colorpicker").ColorPicker({
		onSubmit: function(hsb, hex, rgb, el) {
			$(el).val(hex);
			$(el).ColorPickerHide();
		}, 
		onBeforeShow: function () {
			$(this).ColorPickerSetColor(this.value);
		}
	});
	
	/* Data Tables */
	
	//$(".mws-datatable").dataTable();
	//$(".mws-datatable-fn").dataTable({sPaginationType: "full_numbers", bSort:false});
	
	/* imgAreaSelect */
	
	$(".mws-crop-target").imgAreaSelect({
		handles: true, 
		x1: 32, y1: 32, x2: 132, y2: 132, 
		onSelectChange: function(img, selection) {
			$("#crop_x1").val(selection.x1);
			$("#crop_y1").val(selection.y1);
			$("#crop_x2").val(selection.x2);
			$("#crop_y2").val(selection.y2);
		}
	});
	
	/* Full Calendar */
	
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth();
	var y = date.getFullYear();


	$("#mws-calendar").fullCalendar({
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		editable: true,
		events: [
			{
				title: 'All Day Event',
				start: new Date(y, m, 1)
			},
			{
				title: 'Long Event',
				start: new Date(y, m, d-5),
				end: new Date(y, m, d-2)
			},
			{
				id: 999,
				title: 'Repeating Event',
				start: new Date(y, m, d-3, 16, 0),
				allDay: false
			},
			{
				id: 999,
				title: 'Repeating Event',
				start: new Date(y, m, d+4, 16, 0),
				allDay: false
			},
			{
				title: 'Meeting',
				start: new Date(y, m, d, 10, 30),
				allDay: false
			},
			{
				title: 'Lunch',
				start: new Date(y, m, d, 12, 0),
				end: new Date(y, m, d, 14, 0),
				allDay: false
			},
			{
				title: 'Birthday Party',
				start: new Date(y, m, d+1, 19, 0),
				end: new Date(y, m, d+1, 22, 30),
				allDay: false
			},
			{
				title: 'Click for Google',
				start: new Date(y, m, 28),
				end: new Date(y, m, 29),
				url: 'http://google.com/'
			}
		]
	});
	
	/* Sourcerer */
	
	$(".mws-code-html").sourcerer('html');
	
	/* Validation Plugin */
	
	$("#mws-validate").validate({
		rules: {
			spinner: {
				required: true, 
				max: 5
			}
		}, 
		invalidHandler: function(form, validator) {
			var errors = validator.numberOfInvalids();
			if (errors) {
				var message = errors == 1
				? '您还有1项必填项未完成设置'
				: '您还有' + errors + '项必填项未完成设置';
				$("#mws-validate-error").html(message).show();
			} else {
				$("#mws-validate-error").hide();
      		}
		}
	});
	
	/* jGrowl Notifications */
	
	$("#mws-growl-btn").bind("click", function(event) {
		$.jGrowl("Hello World!", {position: "bottom-right"});
	});
	
	$("#mws-growl-btn-1").bind("click", function(event) {
		$.jGrowl("A sticky message", {sticky: true, position: "bottom-right"});
	});
	
	$("#mws-growl-btn-2").bind("click", function(event) {
		$.jGrowl("Message with Header", {header: "Important!", position: "bottom-right"});
	});
	
	/* Smart Wizard */
	
	if($.fn.smartWizard) {
		$("#smart-wizard").smartWizard({
			onShowStep: function(obj) {
				obj.parents(".tagul").children(".tagli").each(function() {
					var el = $(this).removeClass("current done disabled");
					el.children(".tagli a").each(function() {
						if($(this).hasClass("disabled")) {
							el.addClass("disabled");
						} else if($(this).hasClass("done")) {
							el.addClass("done");
						} else {
							el.addClass("current");
						}
					});
				});
			}
		});
	}


	//卓杰
	$("#edityue,#editshouxin,#addjiangjin,#addbeizhu").bind("click", function(event) {
		var actionurl = $(this).attr("editurl");
		$('#content').hide('fast',loadContent);
		function loadContent() {
			$('#content').load(actionurl,'',showNewContent());
		}
		function showNewContent() {
			$('.loaderIcon').hide();
		}
		$("#mws-form-dialog").dialog({
			autoOpen: false, 
			title: $(this).attr("title"), 
			modal: true, 
			width: "640",
			position: "top",
			buttons: [{
					text: "递交", 
					click: function() {
						formstuat = $( this ).find('form#mws-validate').valid();
						if(formstuat == true){
							jQuery.ajax({
								url: actionurl,
								data: $('#mws-validate').serialize(),
								type: "POST",
								beforeSend: function() {
								},
								success: function(msg) {
									alert(msg);
								},
							});
							return false;
						}
					}}]
		}).dialog("open");
		event.preventDefault();
	});

	$(".searchmenu").bind("click", function(event) {
		var searchkey = $("#searchmenukey").val();
		$.ajax({ 
			type: "POST", 
			dataType: "html",
			url: "?index-searchmenu.htm", 
			data: "key=" + encodeURIComponent(searchkey),
			success: function(message){
				var json = eval("(" + message + ")");
				$("#searchmenuul").html("");
				for(i = 0; i < json.length; i++){
					$("#searchmenuul").append("<a style='text-decoration:none; color:#fff' href='"+json[i]['page']+"'><li class='mws-button blue large' style='margin:10px 10px 10px 10px;'>"+json[i]['name']+"</li></a>");
				}
				$("#searchmenudialog").dialog("option", {modal: true}).dialog("open");
			} //操作成功后的操作！msg是后台传过来的值 
		}); 
	});
	$("#searchmenudialog").dialog({
		autoOpen: false, 
		title: "搜索管理功能", 
		modal: true, 
		width: "640", 
		buttons: [{
			text: "关闭窗口", 
			click: function() {
				$( this ).dialog( "close" );
			}}]
	});

	//删除新闻分类
	$(".zjdel").live("click", function() {
		var zid = $(this).attr("zid");
		var zjdelurl = $(this).attr("zjdelurl");
		$.ajax({ 
			type: "POST", 
			dataType: "html",
			url: zjdelurl, 
			data: "id=" + zid,
			success: function(message){
				var json = eval("(" + message + ")");
				alert(json.msg);
				if(json.stuat == 1){
					$("#zjlist_" + zid).remove();
				}else{
					return false;
				}
			} //操作成功后的操作！msg是后台传过来的值 
		}); 
	});

	//查看留言
	$("#lookfeedback").bind("click", function(event) {
		var zjid = $(this).attr("zjid");
		var teltype = $("#teltype_" + zjid).html();
		var telinfo = $("#telinfo_" + zjid).html();
		var infos = $("#infos_" + zjid).html();
		$("#backlookteltype").html(teltype + '：' + telinfo);
		$("#infos").html("内容：" + infos);
		$("#feedbacklook").dialog("option", {modal: true}).dialog("open");
		event.preventDefault();
	});
	$("#feedbacklook").dialog({
		autoOpen: false, 
		title: "查看留言", 
		modal: true, 
		width: "640", 
		buttons: [{
			text: "关闭窗口", 
			click: function() {
				$( this ).dialog( "close" );
			}}]
	});

	var opts = {
		'number': {decimals:2}
	};

	for (var n in opts)
		$("."+n).spinner();

	$(".delinput").click(function () {
		if($(this).attr("zjid") >= 1){
			$(this).remove("#input_" + $(this).attr("zjid"));
		}else{
			$(this).parent().parent(".mws-form-row").remove();
		}
	});

	$(".nonetoblock").click(function () {
		var blockid = $(this).attr("zjid");
		var displaystuat = $("#none_" + blockid).css('display');
		if(displaystuat == "none"){
			$("#none_" + blockid).show();
		}else{
			$("#none_" + blockid).hide();
		}
	});
$(".addsinput").click(function () {
	var classid = "#" + $(this).parent().parent().parent().parent().parent().parent().parent().parent().attr("id");
	var inputlength = $('input[name="field_name[]"]').length;
	var newinputlength = inputlength + 1;
	field_name = $(classid + ' #field_names').val();
	field_enname = $(classid + ' #field_ennames').val();
	field_beizhu = $(classid + ' #field_beizhus').val();
	field_type = $(classid + ' #field_types').val();
	if(field_enname == ''){
		alert('表单英文标题必填！');
		return false;
	}else if(field_name == ''){
		alert('表单中文标题必填！');
		return false;
	}else if($('#'+field_enname)[0]){
		alert('该字段已经存在！');
		return false;
	}else if(field_type == 0){
		alert('未选择字段类型！');
		return false;
	}
	appinput(classid, newinputlength, field_name, field_enname, field_beizhu, field_type);
});
});
window.uploadId = 0;
function appinput(classid, newinputlength, field_name, field_enname, field_beizhu, field_type) {
	if(field_enname == ''){
		alert('表单英文标题必填！');
		return false;
	}else if(field_name == ''){
		alert('表单中文标题必填！');
		return false;
	}
	if($('#'+field_enname)[0]){
		alert(field_enname + '字段已经存在！');
		return false;
	}
	if(field_type == 0){
		alert('未选择字段类型！');
		return false;
	}else if(field_type == 1){
		field_code = '<input type="text" id="' + field_enname + '" value="" name="field_info[]" placeholder="' + field_beizhu + '" class="mws-textinput required">';
	}else if(field_type == 2){
		field_code = '<textarea id="' + field_enname + '" class="required" cols="auto" rows="auto" name="field_info[]" placeholder="' + field_beizhu + '"></textarea>';
	}else if(field_type == 3){
		field_code = '<textarea id="' + field_enname + '" class="required" cols="auto" rows="auto" name="field_info[]" placeholder="' + field_beizhu + '"></textarea>';
	}else if(field_type == 4){
		field_code = '<input id="files_'+field_enname+'" value="" type="hidden" name="field_info[]"><div class="customfile" id="' + field_enname + '"><input id="file_'+field_enname+'" type="file" name="file_'+field_enname+'"><span class="customfile-feedback" id="filename_'+field_enname+'">没有选择文件！</span></div><SCRIPT type=text/javascript>addupload("'+field_enname+'", 1);</SCRIPT>';
	}else if(field_type == 5){
		field_code = '<select class="required valid" name="field_info[]" id="'+field_enname+'"><option value="1">开启/是</option><option value="2">关闭/否</option></select>';
	}else if(field_type == 6){
		field_code = '<input type="hidden" name="field_info[]" id="picnum_'+field_enname+'" value="0"><ul id="mws-gallery" class="clearfix mws-gallery_'+field_enname+'"><li><span class="mws-gallery-overlayadd" style="display:block"><span id="file_'+field_enname+'" class="mws-gallery-add"></span><div id="filePictures_'+field_enname+'" style="display:none"></div></span></li></ul><SCRIPT type=text/javascript>addupload("'+field_enname+'", 2);</SCRIPT>';
	}
	nojclassid = classid.replace("#", ""); 
	$(classid).append('<div class="mws-form-row" id="input_'+newinputlength+'"><label>' + field_name + '<input type="hidden" name="field_name[]" value="' + field_name + '"><input type="hidden" name="field_id[]" value="' + nojclassid + '"><input type="hidden" name="field_enname[]" value="' + field_enname + '"><input type="hidden" name="field_beizhu[]" value="' + field_beizhu + '"><input type="hidden" name="field_type[]" value="' + field_type + '">：</label><div class="mws-form-item clearfix"><div class="mws-form-cols clearfix"><div class="mws-form-col-7-8 alpha"><div class="mws-form-item">' + field_code + '</div></div><div class="mws-form-col-1-8 omega"><div class="mws-form-item"><label><div style="height:16px;width:16px;margin-top:5px;" onclick="delinput(\''+newinputlength+'\');" class="mws-ic-16 ic-cross delinput" title="删除该条"></div></label></div></div></div></div>');
	if(field_type == 3){
		$.getScript('skin/plugins/kindeditor/kindeditor-min.js', function() {
			KindEditor.basePath = 'skin/plugins/kindeditor/';
			editor = KindEditor.create('textarea[id="' + field_enname + '"]',{afterBlur:function(){this.sync();}});
		});
	}
}
function delinput(id) {
	$("#input_" + id).remove();
}
function delpics(id) {
	$("#" + id).remove();
}
function addeditor(field_enname) {
	$.getScript('skin/plugins/kindeditor/kindeditor-min.js', function() {
		KindEditor.basePath = 'skin/plugins/kindeditor/';
		editor = KindEditor.create('textarea[id="' + field_enname + '"]',{afterBlur:function(){this.sync();}});
	});
}

function addupload(field_enname, type){
		if(type == 1){
			var buttonText = '浏览';
		}else{
			var buttonText = ' ';
		}
		var idname = "#file_" + field_enname;
		$(idname).uploadify({
			swf              : '../upload/js/uploadify.swf',
			uploader         : "../upload/uploadify.php",
			cancelImg        : '../upload/js/cancel.gif',
    		formData      : {'type' : 'image'},
     		removeTimeout 	 : 0,
			queueID          : 'fileIcon',
            method		     : 'POST',
            fileTypeDesc	 : '注意:您只能上傳apk格式的文件!',
            fileTypeExts	 : '*.png;*.jpg;*.gif;',
			buttonClass : 'customfile-button',
			buttonText       : buttonText,
			multi: true,
            auto             : true,
			onSelect : function(file) {
			}, 
			onUploadError 	: function(file, errorCode, errorMsg, errorString) {
				if(type == 1){
					alert('文件：' + file.name + ' 不能上傳,出錯: ' + errorString);
				}
			},
			onUploadSuccess  : function(file, data, response) {
				if(type == 1){
					$('#files_'+field_enname).val(data);
					$('#filename_'+field_enname).html(data);
				}else{
					var inputlength = $("#picnum_"+field_enname).val();
					var datas = data.split('||');
					var str='<li id="pics_'+field_enname+'_'+inputlength+'"><input type="hidden" name="field_info'+field_enname+'[]" value="'+datas[0]+'"><img src="../upload/'+datas[0]+'"><span class="mws-gallery-overlay"><a href="../upload/'+datas[0]+'"  rel="prettyPhoto[gallery1]" class="mws-gallery-btn"><span class="mws-gallery-zoom"></span></a><a href="javascript:delpics(\'pics_'+field_enname+'_'+inputlength+'\');" class="mws-gallery-btn"><span class="mws-gallery-del"></span></a></span></li>';
					$('.mws-gallery_'+field_enname).append(str);
					$("#picnum_"+field_enname).val(parseInt(parseInt(inputlength)+1));
					$("a[rel^='prettyPhoto']").prettyPhoto();
				}
			}
		});
}

function addappinputdata(classid, appid){
	var inputlength = $('input[name="field_name[]"]').length;
	var newinputlength = inputlength + 1;
	var appid = $("#" + appid).val();
	if(isNaN(appid)){
		alert('应用ID必须为整数并且不为0！');
	}else if(parseInt(appid) != appid){
		alert('应用ID必须为整数，不带任何小数点或符号及空格！');
	}else if(appid < 1){
		alert('应用ID必须大于0！');
	}
	$.getJSON("http://m.apk.tw/?api-appinfo-id-" + appid + ".htm?jsoncallback=?",function(json) {
			if(json.stuat == 1){
				//获取成功
				$("#name").val(json.app.name);
				$("#picinput").val(json.app.icon);
				$(".changtu").html(json.app.icon);
				appinput(classid, newinputlength, '下载方式', 'downstuat', '如非下载方式则为打开网页方式', 5);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '站内储值', 'sitepay', '是否开启平台内储值？', 5);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '站外储值', 'partpay', '是否开启平台外储值？例如游戏内直接储值', 5);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '版本号', 'varsion', '应用文件版本号', 1);
				$("#varsion").val(json.app.varsion);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '更新时间', 'update', '应用最后更新时间', 1);
				$("#update").val(getLocalTime(json.app.update));
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '大小', 'size', '应用安装包文件大小', 1);
				$("#size").val(json.app.size);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '下载地址', 'apkurl', '应用下载地址', 1);
				$("#apkurl").val(json.app.apkurl);
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '截图', 'thum', '获取应用中心截图信息，不可修改！', 6);
				var _test = eval("(" + json.app.thum + ")");
				for(a=0;a<_test.length;a++){
					$(".mws-gallery_thum").append('<li id="pics_thum_'+a+'"><input type="hidden" name="field_infothum[]" value="'+_test[a].ImgUrl+'"><img src="'+_test[a].ImgUrl+'"><span class="mws-gallery-overlay"><a href="'+_test[a].ImgUrl+'"  rel="prettyPhoto[gallery1]" class="mws-gallery-btn"><span class="mws-gallery-zoom"></span></a><a href="javascript:delpics(\'pics_thum_'+a+'\');" class="mws-gallery-btn"><span class="mws-gallery-del"></span></a></span></li>');
				}
				newinputlength = newinputlength + 1;
				appinput(classid, newinputlength, '应用介绍', 'contents', '应用文字介绍信息！', 3);
				$("#contents").val(json.app.contents);
				$("a[rel^='prettyPhoto']").prettyPhoto();
				alert('获取应用中心数据成功！');
			}else if(json.stuat == 2){
				//数据有问题
				alert(json.msg);
			}else{
				//获取失败
				alert('数据获取失败，请重试！');
			}
		});
	return false;
}   
function getLocalTime(nS) {     
   return new Date(parseInt(nS) * 1000).toLocaleString().replace(/年|月/g, "-").replace(/日/g, " ");
}
/* 显示遮罩层 */
function showOverlay() {
	$('body').append('<div id="overlay"><div class="loading"></div></div>');
    $("#overlay").height(pageHeight());
    $("#overlay").width(pageWidth());

    // fadeTo第一个参数为速度，第二个为透明度
    // 多重方式控制透明度，保证兼容性，但也带来修改麻烦的问题
    $("#overlay").fadeTo(200, 0.5);
}

/* 隐藏覆盖层 */
function hideOverlay() {
    $("#overlay").fadeOut(200);
}

/* 当前页面高度 */
function pageHeight() {
    return document.body.scrollHeight;
}

/* 当前页面宽度 */
function pageWidth() {
    return document.body.scrollWidth;
}