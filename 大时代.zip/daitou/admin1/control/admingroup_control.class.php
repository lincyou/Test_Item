<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class admingroup_control extends admin_control{
	
	function __construct() {
		parent::__construct();
		$this->on_checkmodel('admins');
	}
        
    //管理组管理
	function on_list(){
		$edit = 0;
		$this->view->assign('edit', $edit);
		$this->view->display('admingroup_list.htm');
	}
        
    //管理组管理API
	function on_listapi(){
		$userlist = $where = array();
		$pagesize = intval(core::gpc('iDisplayLength', 'P'));
		$start = intval(core::gpc('iDisplayStart', 'P'));
		$searchkey = urldecode(core::gpc('sSearch', 'P'));
		$sEcho = urldecode(core::gpc('sEcho', 'P'));
		if(!empty($searchkey)){
			$where['name'] = array('LIKE' => $searchkey);
		}
		$num = $this->admingroup->total($where);
		$infos = $this->admingroup->index_fetch($where, array('id' => 2), $start, $pagesize);
		foreach($infos as $k => $v){
			$userlist[] = array($v['id'], $v['name'], $v['num'], '');
		}
		$json['iTotalRecords'] = $num;
		$json['iTotalDisplayRecords'] = $num;
		$json['sEcho'] = $sEcho;
		$json['aaData'] = $userlist;
		echo json_encode($json);
		exit;
	}
        
    //增加管理组
	function on_add(){
		$edit = 0;
		$this->view->assign('edit', $edit);
		$model = $this->mcache->read('model');
		$this->view->assign('model', $model);
		$this->view->display('admingroup_add.htm');
	}
        
    //增加管理组API
	function on_addapi(){
		$group['name'] = core::gpc('name', 'P');
		$group['system'] = implode('|', core::gpc('system', 'P'));
		if(!empty($group['name'])){
			$where = array('name' => $group['name']);
			$count = $this->admingroup->total($where);
			if($count >= 1){
				$error = array('msg' => "管理组名重复！", 'stuat' => 2);
			}else{
				$group['num'] = 0;
				$group['id'] = $this->admingroup->create($group);
				if($group['id'] >= 1){
					/*
					$adminlogdb = array(
						'admin_name' => $this->_admin['username'],
						'id' => $manage['id'],
						'title' => $manage['username'],
					);
					$this->adminlog->admin_log($this->_admin['id'], 38, $adminlogdb);
					*/
					$this->mcache->clear('admingroup');
					$error = array('msg' => "添加管理组成功！", 'stuat' => 1, 'id' => $group['id']);
				}else{
					$error = array('msg' => "数据库出错，未保存数据！", 'stuat' => 2);
				}
			}
		}else{
			$error = array('msg' => "管理组名称都不能为空！", 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
        
    //删除管理组
	function on_delapi(){
		$id = intval(core::gpc('id', 'R'));
		$group = $this->admingroup->get($id);
		if(empty($group)){
			$msg = array(
				'stuat' => 2,
				'msg' => "管理组不存在！",
			);
		}else{
			if($group['num'] >= 1){
				$msg = array(
					'stuat' => 2,
					'msg' => "管理组中还有管理员，不能删除！",
				);
				echo json_encode($msg);
				exit;
			}
			//$jiu = $this->adminlog->field_info($manage, 3);
			$delstuat = $this->admingroup->_delete($id);
			if($delstuat == 1){
				/*
				$adminlogdb = array(
					'admin_name' => $this->_admin['username'],
					'id' => $manage['id'],
					'title' => $manage['username'],
					'jiu' => $jiu,
				);
				$this->adminlog->admin_log($this->_admin['id'], 40, $adminlogdb);
				*/
				$this->mcache->clear('admingroup');
				$msg = array(
					'stuat' => 1,
					'msg' => "删除管理组成功！",
				);
			}else{
				$msg = array(
					'stuat' => 2,
					'msg' => "删除管理组失败！",
				);
			}
		}
		echo json_encode($msg);
		exit;
	}

	//编辑管理组API
	function on_editapi(){
		$id = intval(core::gpc('id', 'P'));
		$group = $this->admingroup->get($id);
		if(!empty($group)){
			if($this->form_submit()) {
				$group['name'] = core::gpc('name', 'P');
				$group['system'] = implode('|', core::gpc('system', 'P'));
				$upstuat = $this->admingroup->update($group['id'], $group);
				if($upstuat >= 1){
					/*
					$adminlogdb = array(
						'admin_name' => $this->_admin['username'],
						'id' => $manage['id'],
						'title' => $manage['username'],
					);
					$this->adminlog->admin_log($this->_admin['id'], 38, $adminlogdb);
					*/
					$this->mcache->clear('admingroup');
					$error = array('msg' => "编辑管理组成功！", 'stuat' => 1, 'id' => $group['id']);
				}else{
					$error = array('msg' => "数据库出错，未保存数据！", 'stuat' => 2);
				}
			}
		}else{
			$error = array('msg' => "数据不存在，请重新确认！", 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
        
    //编辑管理组
	function on_edit(){
		$id = intval(core::gpc('id', 'R'));
		$admingroup = $this->admingroup->get($id);
		if(empty($admingroup)){
			$error = array('msg' => "数据不存在，请重新确认！", 'stuat' => 2);
			$this->index->error($error, $menuid);
			exit;
		}
		$edit = 1;
		$this->view->assign('edit', $edit);
		$system = explode("|", $admingroup['system']);
		$admingroup['system'] = array();
		foreach($system as $k => $v){
			$admingroup['system'][$v] = 1;
		}
		$model = $this->mcache->read('model');
		$this->view->assign('model', $model);
		$this->view->assign('admingroup', $admingroup);
		$this->view->display('admingroup_add.htm');
	}
}

?>