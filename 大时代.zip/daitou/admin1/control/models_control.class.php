<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');

class models_control extends admin_control{
	function __construct() {
		$m = core::gpc('m', 'R');
		$class_file = BBS_PATH.'models/'.$m.'/class.php';
		if(is_file($class_file)){
			include $class_file;
		}else{
			header("HTTP/1.1 404 Not Found");  
			header("Status: 404 Not Found");  
			exit;
		}
	}
	
	function on_f() {
		$m = core::gpc('m', 'R');
		$this->conf['view_path'] = array(BBS_PATH.'models/'.$m.'/view/');
		$n = core::gpc('n', 'R');
		$function_file = BBS_PATH.'models/'.$m.'/'.$n.'.php';
		if(is_file($function_file)){
			include $function_file;
		}else{
			header("HTTP/1.1 404 Not Found");  
			header("Status: 404 Not Found");  
			exit;
		}
	}
}
?>