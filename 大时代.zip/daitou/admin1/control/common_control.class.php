<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
include BBS_PATH.'control/common_control.class.php';
class admin_control extends common_control {
	
	// hook admin_control_start.php
	
	function __construct() {
		parent::__construct();
		
		// 这里可能会有跨站脚本导致的提交，可以触发安全警报。管理员应该定期查看后台日志。
		//$this->check_mod_group();
		$admin_auth = core::gpc($this->conf['cookiepre'].'admin_auth', 'R');

		$login = 0;
		if(empty($admin_auth)) {
			// 登录页面放行
			 if(!(core::gpc(0) == 'index' && (core::gpc(1) == 'login' || core::gpc(1) == 'logout' || core::gpc(1) == 'code'))) {
				$login = 1;
			}
		} else {
			$browser = md5(core::gpc('HTTP_USER_AGENT', 'S'));
			$key = $this->conf['public_key']."admin".$browser;
			$s = decrypt($admin_auth, $key);
			if(empty($s)) {
				$login = 1;
			} else {
				$arr = explode("\t", $s);
				if(empty($arr)) {
					$login = 1;
				} else {
					list($id, $username, $password, $ip, $time) = $arr;
					/*
						1. 超出一小时，退出登录，设置一天，解决时差问题。
						2. IP发生变化，退出登录
						3. 更换浏览器，退出登录
					*/
					//if($_SERVER['time'] - $time > 86400 || $ip != $_SERVER['REMOTE_ADDR']) {
					if($_SERVER['time'] - $time > 86400) {
						$login = 1;
						//echo $ip ."--". $_SERVER['REMOTE_ADDR']."--".$_SERVER['time']."--".$time;exit;
					}else{
						if(!empty($this->_admin['system'])){
							$this->conf['system'] = json_decode($this->_admin['system'], true);
						}else{
							$systems = $this->mcache->read('admin', 'models', 'group_cache');
							if(!empty($systems[$this->_admin['groupid']])){
								$system = $systems[$this->_admin['groupid']]['system'];
							}else{
								$system = array();
							}
							$this->conf['system'] = $system;
						}
						if(!empty($this->_admin['changyong'])){
							$this->conf['changyong'] = json_decode($this->_admin['changyong'], true);
						}else{
							$this->conf['changyong'] = array();
						}
					}
				}
			}
			// dateline	ip	browser
		}
		if($login){
			if(empty($id)){
				$id = 0;
				$username = '';
				$stuatid = 36;
			}else{
				$stuatid = 35;
			}
			/*
			$adminlogdb = array(
				'admin_name' => $username,
				'ip' => $_SERVER['REMOTE_ADDR'],
			);
			$this->adminlog->admin_log($id, $stuatid, $adminlogdb);
			*/
			misc::set_cookie($this->conf['cookiepre'].'admin_auth', '', $_SERVER['time'], '/');
			echo '<html><body><script>top.location="./login.html"</script></body></html>';
			exit;
		}
	}
        
        //网站配置
        public function on_conf(){
			$conffile = BBS_PATH.'conf/conf.php';
			$input = array();
			$error = $post = array();
			if($this->form_submit()) {
				$tixian_limit = intval(core::gpc('tixian_limit', 'P'));
				if(misc::values_empty($error)) {
					$error = array();
					if(!is_file($conffile)) {
							$this->message($conffile.' 文件不存在！');
					}
					if(!is_writable($conffile)) {
						$this->message($conffile.' 文件不可写！');
					}
					$s = file_get_contents($conffile);
					$this->mconf->set_to('tixian_limit', $tixian_limit, $conffile);
					$this->mconf->save();
					$this->message('编辑配置信息成功。', 1, "?admin-conf.htm");
				}
			}
			$conf = include $conffile;
			$tixian_limit = isset($conf['tixian_limit'])?$conf['tixian_limit']:'';
			$this->view->assign('tixian_limit', $tixian_limit);
			$this->view->display('admin_base.htm');
        }

	
	// 是否为最高级别的管理员
	protected function check_admin_group() {
		if($this->_group['groupid'] != 1) {
			$this->message('对不起，您不是管理员，无权访问。');
		}
	}
        
        //获取用户权限列表
        protected function get_pop_action() {
                $grouplist = $this->group->index_fetch(array(), array());
                foreach( $grouplist as $group ){
                    $purview = $group['purview'];
                    $popArr = json_decode($purview);
                    
                    if( count($popArr) >= 1 ){
                        foreach($popArr as $pop){

                                $arr  = is_object($pop) ? get_object_vars($pop) : $pop; 
                                if( is_array($arr) ){
                                    foreach($arr as $key => $val){
                                        if( $key == $this->_user['uid'] ){
                                            $this->_user['accesson'][] = $val;
                                        }
                                    }
                                }else{
                                    $this->_user['accesson'] = array();
                                }
                        }
                    }else{
                                    $this->_user['accesson'] = array();
                                }
                    
                }
	}
	
	protected function check_mod_group() {
		if($this->_group['groupid'] == 0 || $this->_group['groupid']  > 5) {
			log::write("非法尝试后台登录", 'login.php');
			$this->message('对不起，您所在的用户组不是管理组，无权访问。');
		}
	}
	protected function check_user_exists($info) {
		if(empty($info)) {
			$this->message('用户信息不存在！可能已经被删除。', 0);
		}
	}
	
	function on_error($error, $url = '') {
		$this->check_adminlogin();
		$this->view->assign('error', $error);
		if(empty($url)){
			$url = "javascript:history.back()";
		}
		$this->view->assign('url', $url);
		$this->conf['view_path'] = array(BBS_PATH.ADMIN_PATH.'/view/');
		$this->view->display('admin_error.htm');
		exit;
	}

	function on_checkmodel($modelname) {
		$menuid = 0;
		if(empty($this->conf['menu'][$modelname]['stuat'])){
			$this->on_error('模块未开启！', 0, 1, $this->conf['app_url']."admin/?index-index.htm");
		}
		$menuid = $this->conf['menu'][$modelname]['id'];
		if($this->_admin['groupid'] != 1 and empty($this->_admin_system[$menuid])){
			$this->adminlog->admin_log($this->_admin['id'], 5, array('admin_name' => $this->_admin['username'], 'title' => $admin_group[$menuid]['name']));
			$error = array('stuat' => 2, 'msg' => '权限不足，不能访问该功能，你的违规操作已经被记录！');
			$this->index->error($error, $menuid);
		}
		$this->view->assign('menuid', $menuid);
		$this->view->assign('admin_group', $admin_group);
	}

	function on_checksystem($systemid){
		if(empty($this->conf['system'][$systemid]) and $this->_admin['groupid'] != 1){
			header("Location: ./?index-loginout.htm");
			exit;
		}
	}
}

?>