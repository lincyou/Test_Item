<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class manage_control extends admin_control{
	function __construct() {
		parent::__construct();
		$this->on_checkmodel('system');
		$this->check_adminlogin();
		$this->check_admintwopassword();
	}
	
	function on_system() {
		$stuat = 0;
		$conffile = BBS_PATH.'conf/conf.php';
		$input = array();
		$error = $post = array();
		if($this->form_submit()) {
			if(misc::values_empty($error)) {
				$error = array();
				if(!is_file($conffile)) {
					$error = $conffile.' 文件不存在！';
					$stuat = 2;
				}
				if(!is_writable($conffile)) {
					$error = $conffile.' 文件不可写！';
					$stuat = 2;
				}
				
				//$jiu = $this->adminlog->field_info($this->conf, 12);
				$confinfo = $this->conf;
				$confinfo['seo_title'] = $seo_title = core::gpc('seo_title', 'P');
				$confinfo['app_url'] = $app_url = core::gpc('app_url', 'P');
				$confinfo['static_url'] = $static_url = core::gpc('static_url', 'P');
				$confinfo['timeoffset'] = $timeoffset = core::gpc('timeoffset', 'P');
				$confinfo['seo_keywords'] = $seo_keywords = core::gpc('seo_keywords', 'P');
				$confinfo['seo_description'] = $seo_description = core::gpc('seo_description', 'P');
				$confinfo['cache_colse'] = $cache_colse = intval(core::gpc('cache_colse', 'P'));
				$confinfo['duanxin_colse'] = $duanxin_colse = intval(core::gpc('duanxin_colse', 'P'));
				$confinfo['duanxin_sn'] = $duanxin_sn = core::gpc('duanxin_sn', 'P');
				$confinfo['duanxin_key'] = $duanxin_key = core::gpc('duanxin_key', 'P');
				$confinfo['qianbaourl'] = $qianbaourl = core::gpc('qianbaourl', 'P');

				$this->mconf->set_to('seo_title', $seo_title, $conffile);
				$this->mconf->set_to('app_url', $app_url, $conffile);
				$this->mconf->set_to('static_url', $static_url, $conffile);
				$this->mconf->set_to('timeoffset', $timeoffset, $conffile);
				$this->mconf->set_to('seo_keywords', $seo_keywords, $conffile);
				$this->mconf->set_to('seo_description', $seo_description, $conffile);
				$this->mconf->set_to('cache_colse', $cache_colse, $conffile);
				$this->mconf->set_to('duanxin_colse', $duanxin_colse, $conffile);
				$this->mconf->set_to('duanxin_sn', $duanxin_sn, $conffile);
				$this->mconf->set_to('duanxin_key', $duanxin_key, $conffile);
				$this->mconf->set_to('qianbaourl', $qianbaourl, $conffile);
				$this->mconf->save();
				
				/*
				$xin = $this->adminlog->field_info($confinfo, 12);
				$liyou = core::gpc('liyou', 'P');
				$adminlogdb = array(
					'admin_name' => $this->_admin['username'],
					'jiu' => $jiu,
					'xin' => $xin,
				);
				$this->adminlog->admin_log($this->_admin['id'], 24, $adminlogdb);
				*/
				$error = '编辑配置信息成功。';
				$stuat = 1;
			}
		}
		$config = include $conffile;
		$tixian_limit = isset($conf['tixian_limit'])?$conf['tixian_limit']:'';
		$this->view->assign('error', $error);
		$this->view->assign('stuat', $stuat);
		$this->view->assign('config', $config);
		$this->view->display('admin_system.htm');
	}
	
	function on_set() {
		$this->view->display('manage_set.htm');
	}
	
	function on_setapi() {
		$conffile = BBS_PATH.'conf/conf.php';
		if($this->form_submit()) {
			$huiyuanjiesuanxitongqiantaistuat = intval(core::gpc('huiyuanjiesuanxitongqiantaistuat', 'P'));
			$huiyuanjiesuanxitongqiantaiclosetip = core::gpc('huiyuanjiesuanxitongqiantaiclosetip', 'P');
			$this->mconf->set_to('huiyuanjiesuanxitongqiantaistuat', $huiyuanjiesuanxitongqiantaistuat, $conffile);
			$this->mconf->set_to('huiyuanjiesuanxitongqiantaiclosetip', $huiyuanjiesuanxitongqiantaiclosetip, $conffile);
			$this->mconf->save();
			$error = array('msg' => '修改前台设置成功！', 'stuat' => 1);
		}else{
			$error = array('msg' => '非法操作！', 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
	
	function on_bonusset() {
		$this->view->display('manage_bonusset.htm');
	}
	
	function on_bonussetapi() {
		$conffile = BBS_PATH.'conf/conf.php';
		if($this->form_submit()) {
			$touzimoney = core::gpc('touzimoney', 'P');
			$dannum = core::gpc('dannum', 'P');
			$tuijianjiang = core::gpc('tuijianjiang', 'P');
			$baodanjiang = core::gpc('baodanjiang', 'P');
			$lingdaojiang = core::gpc('lingdaojiang', 'P');
			$lingdaojiangtop = core::gpc('lingdaojiangtop', 'P');
			$zengdaibi = core::gpc('zengdaibi', 'P');
			$rifenhong = core::gpc('rifenhong', 'P');
			$fenghongtop = core::gpc('fenghongtop', 'P');
			$guanlifenhongtop = core::gpc('guanlifenhongtop', 'P');
			$lantianbishouxufei = core::gpc('lantianbishouxufei', 'P');
			$lantianbitoxianjinbi = core::gpc('lantianbitoxianjinbi', 'P');
			$wangluotu = core::gpc('wangluotu', 'P');
			if($wangluotu == "on"){
				$wangluotu = 1;
			}else{
				$wangluotu = 0;
			}
			$loadxinyong = core::gpc('loadxinyong', 'P');
			$xinyongjia = core::gpc('xinyongjia', 'P');
			$xinyongxiaxian = core::gpc('xinyongxiaxian', 'P');
			$lantianbito = core::gpc('lantianbito', 'P');
			$guanlifei = core::gpc('guanlifei', 'P');

			$this->mconf->set_to('touzimoney', $touzimoney, $conffile);
			$this->mconf->set_to('dannum', $dannum, $conffile);
			$this->mconf->set_to('tuijianjiang', $tuijianjiang, $conffile);
			$this->mconf->set_to('baodanjiang', $baodanjiang, $conffile);
			$this->mconf->set_to('lingdaojiang', $lingdaojiang, $conffile);
			$this->mconf->set_to('lingdaojiangtop', $lingdaojiangtop, $conffile);
			$this->mconf->set_to('zengdaibi', $zengdaibi, $conffile);
			$this->mconf->set_to('rifenhong', $rifenhong, $conffile);
			$this->mconf->set_to('fenghongtop', $fenghongtop, $conffile);
			$this->mconf->set_to('guanlifenhongtop', $guanlifenhongtop, $conffile);
			$this->mconf->set_to('lantianbishouxufei', $lantianbishouxufei, $conffile);
			$this->mconf->set_to('lantianbitoxianjinbi', $lantianbitoxianjinbi, $conffile);
			$this->mconf->set_to('loadxinyong', $loadxinyong, $conffile);
			$this->mconf->set_to('xinyongjia', $xinyongjia, $conffile);
			$this->mconf->set_to('xinyongxiaxian', $xinyongxiaxian, $conffile);
			$this->mconf->set_to('lantianbito', $lantianbito, $conffile);
			$this->mconf->set_to('guanlifei', $guanlifei, $conffile);
			$this->mconf->set_to('wangluotu', $wangluotu, $conffile);
			$this->mconf->save();
			$error = array('msg' => '修改奖项金额成功！', 'stuat' => 1);
		}else{
			$error = array('msg' => '非法操作！', 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
	
	function on_bonuschushihuaapi() {
		$dbtou = $this->conf['db']['mysql']['master']['tablepre'];
		$sql = "UPDATE  `".$dbtou."user` SET  `score7` =  '".$this->conf['loadxinyong']."'";
		$mysqlquery = $this->za->mysqlquery($sql);
		$error = array('msg' => '初始化信用成功！', 'stuat' => 1);
		echo json_encode($error);
		exit;
	}
	
	function on_systembank() {
		$this->view->display('manage_systembank.htm');
	}
	
	function on_systembankapi() {
		$conffile = BBS_PATH.'conf/conf.php';
		if($this->form_submit()) {
			$yinhangfenlei1 = core::gpc('yinhangfenlei1', 'P');
			$yinhangfenlei2 = core::gpc('yinhangfenlei2', 'P');
			$yinhangfenlei3 = core::gpc('yinhangfenlei3', 'P');
			$enyinhangfenlei1 = core::gpc('enyinhangfenlei1', 'P');
			$enyinhangfenlei2 = core::gpc('enyinhangfenlei2', 'P');
			$enyinhangfenlei3 = core::gpc('enyinhangfenlei3', 'P');
			$yinhangname1 = core::gpc('yinhangname1', 'P');
			$yinhangname2 = core::gpc('yinhangname2', 'P');
			$yinhangname3 = core::gpc('yinhangname3', 'P');
			$yinhangzhanghao1 = core::gpc('yinhangzhanghao1', 'P');
			$yinhangzhanghao2 = core::gpc('yinhangzhanghao2', 'P');
			$yinhangzhanghao3 = core::gpc('yinhangzhanghao3', 'P');
			$shoukuanrenname1 = core::gpc('shoukuanrenname1', 'P');
			$shoukuanrenname2 = core::gpc('shoukuanrenname2', 'P');
			$shoukuanrenname3 = core::gpc('shoukuanrenname3', 'P');
			$lianxidianhua1 = core::gpc('lianxidianhua1', 'P');
			$lianxidianhua2 = core::gpc('lianxidianhua2', 'P');
			$lianxidianhua3 = core::gpc('lianxidianhua3', 'P');
			$zhidingtixianyinhangname = core::gpc('zhidingtixianyinhangname', 'P');

			$this->mconf->set_to('yinhangfenlei1', $yinhangfenlei1, $conffile);
			$this->mconf->set_to('yinhangfenlei2', $yinhangfenlei2, $conffile);
			$this->mconf->set_to('yinhangfenlei3', $yinhangfenlei3, $conffile);
			$this->mconf->set_to('enyinhangfenlei1', $enyinhangfenlei1, $conffile);
			$this->mconf->set_to('enyinhangfenlei2', $enyinhangfenlei2, $conffile);
			$this->mconf->set_to('enyinhangfenlei3', $enyinhangfenlei3, $conffile);
			$this->mconf->set_to('yinhangname1', $yinhangname1, $conffile);
			$this->mconf->set_to('yinhangname2', $yinhangname2, $conffile);
			$this->mconf->set_to('yinhangname3', $yinhangname3, $conffile);
			$this->mconf->set_to('yinhangzhanghao1', $yinhangzhanghao1, $conffile);
			$this->mconf->set_to('yinhangzhanghao2', $yinhangzhanghao2, $conffile);
			$this->mconf->set_to('yinhangzhanghao3', $yinhangzhanghao3, $conffile);
			$this->mconf->set_to('shoukuanrenname1', $shoukuanrenname1, $conffile);
			$this->mconf->set_to('shoukuanrenname2', $shoukuanrenname2, $conffile);
			$this->mconf->set_to('shoukuanrenname3', $shoukuanrenname3, $conffile);
			$this->mconf->set_to('lianxidianhua1', $lianxidianhua1, $conffile);
			$this->mconf->set_to('lianxidianhua2', $lianxidianhua2, $conffile);
			$this->mconf->set_to('lianxidianhua3', $lianxidianhua3, $conffile);
			$this->mconf->set_to('zhidingtixianyinhangname', $zhidingtixianyinhangname, $conffile);
			$this->mconf->save();
			$error = array('msg' => '修改公司账号设置成功！', 'stuat' => 1);
		}else{
			$error = array('msg' => '非法操作！', 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
}

?>