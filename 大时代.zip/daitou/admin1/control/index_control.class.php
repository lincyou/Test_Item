<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class index_control extends admin_control {
	
	function __construct() {
		parent::__construct();
	}

public function on_indexs() {
	print_r(get_included_files());
	echo number_format(microtime(1) - $_SERVER['starttime'], 4);
}
	
	public function on_login() {
		ob_start();
		session_start();
		$error = '';
		$stuat = 0;
		$username = "";
		$password = "";
		$referer = core::gpc('HTTP_REFERER', 'S');
		if(strpos($referer, 'index-logout') !== FALSE || strpos($referer, 'index-login') !== FALSE) {
			$referer = '';
		}
		if($this->form_submit()){
			$referer = core::gpc('referer', 'P');
			$username = core::gpc('username', 'P');
			$password = core::gpc('password', 'P');
			$captcha = core::gpc('captcha', 'P');
			if(empty($_SESSION['code']) or strtolower($captcha) != strtolower($_SESSION['code'])){
				$error = '验证码错误！';
			}else if(!$this->admins->verify_password($username, $password)) {
				//$this->adminlog->admin_log(0, 2, array('admin_name' => $username, 'title' => $password));
				$error = '用户名或密码错误！';
			}else{
				//获取用户信息
				$info = $this->admins->get_user_by_username($username);
				$info['login_time'] = $_SERVER['time'];
				$info['login_ip'] = $_SERVER['REMOTE_ADDR'];
				$this->admins->update($info['id'], $info);
				$this->adminlog->admin_log($info['id'], 1, array('admin_name' => $username));
				$this->admins->set_login_cookie($info);
				/*
				if(!empty($referer)){
					header("location:".$referer);
				}else{
					header("location:".'./index.html');
				}
				*/
				header("location:".'./index.html');
			}
		}
		//用户登录时，跳转页面
		if(!empty($this->_admin["id"])){
			header("location:".$this->conf["app_url"]);
		}
		$this->view->assign('referer', $referer);
		$this->view->assign('error', $error);
		$this->view->assign('stuat', $stuat);
		$this->view->assign('username', $username);
		$this->view->assign('password', $password);
		$this->view->display('index_login.htm');
	}
        
	public function encrypt_auth($uid, $username, $password, $groupid = '', $accesson = '') {
		$browser = md5(core::gpc('HTTP_USER_AGENT', 'S'));
		$key = $this->conf['public_key'].$browser;
		$password = substr($password, 0, 8);
		
		$time = $_SERVER['time'];
		$ip = $_SERVER['REMOTE_ADDR'];
		
		// 所有项目中，不允许有\t，否则可能会被伪造
		$xn_auth = encrypt("$uid	$username	$groupid	$password	$ip	$time	$accesson", $key);
		return $xn_auth;
	}
        
	public function get_xn_auth($user) {
		if(empty($user)) {
			return '';
		}
		$xn_auth = $this->encrypt_auth($user['id'], $user['username'], $user['password']);
		return $xn_auth;
	}
        
	public function set_login_cookie($user) {
		// 包含登录信息，重要。HTTP_ONLY
		$xn_auth = $this->get_xn_auth($user);
		misc::set_cookie($this->conf['cookiepre'].'admin_auth', $xn_auth, $_SERVER['time'] + 86400 * 30, '/', TRUE);
	}
	
	function on_loginout() {
		ob_start();
		session_start();
		$this->adminlog->admin_log($this->_admin['id'], 34, array('admin_name' => $this->_admin['username']));
		misc::set_cookie($this->conf['cookiepre'].'admin_auth', '', $_SERVER['time'], '/');
		$_SESSION['admin_two_password'] = '';
		header("location:./login.htm");
		exit;
	}
	
	
	public function on_index() {
		$this->check_adminlogin();
		$menuid = 999;
		$menu = array();
		/*
		$models = $this->mcache->read('model');
		foreach($models as $k => $v){
			if(file_exists(BBS_PATH."models/".$v['files']."/config.php") == true){
				$model_info = include BBS_PATH."models/".$v['files']."/config.php";
				$menu[$v['files']] = array_merge($v, $model_info);
			}
		}
		*/
		$app_store = $this->mcache->read("appstore", "models");
		$applist = $this->mcache->read("applist", "models");
		$this->view->assign('menu', $menu);
		$this->view->assign('menuid', $menuid);
		$this->view->display('index.htm');
	}
	
	
	public function on_twopassword() {
		ob_start();
		session_start();
		$this->check_adminlogin();
		//$this->check_admintwopassword();
		$menuid = 999;
		$purl = "";
		$uri = $this->za->url_uri();
		if(!empty($uri['index-twopassword.htm?purl'])){
			$purl = $uri['index-twopassword.htm?purl'];
		}
		$this->view->assign('purl', $purl);
		$this->view->assign('menuid', $menuid);
		$this->view->display('twopassword.htm');
	}
	
	public function on_twopasswordapi() {
		ob_start();
		session_start();
		$password = core::gpc('password', 'P');
		if($password != $this->_admin['two_password']){
			$error = array('msg' => '二级密码错误！', 'stuat' => 2);
		}else{
			$_SESSION['admin_two_password'] = md5($password);
			$error = array('msg' => '', 'stuat' => 1);
		}
		echo json_encode($error);
		exit;
	}

	public function on_code1() {
		ob_start();
		session_start();
		$seccode = $this->za->make_varchar(4);
		$_SESSION['code'] = $seccode;
		@header("Expires: -1");
		@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
		@header("Pragma: no-cache");
		$this->c('seccode');
		$code = $this->seccode;
		//$code = new seccode();
		$code->code = $seccode;
		$code->width = 90;
		$code->height = 26;
		$code->background = 1;
		$code->adulterate = 1;
		$code->scatter = '';
		$code->color = 1;
		$code->size = 0;
		$code->shadow = 1;
		$code->animator = 0;
		$code->datapath =  BBS_PATH.'data/resource/seccode/';
		$code->display();
	}

	public function on_code() {
		ob_start();
		session_start();
		$str = "1,2,3,4,5,6,7,8,9,a,b,c,d,f,g";      //要显示的字符，可自己进行增删
		$list = explode(",", $str);
		$cmax = count($list) - 1;
		$verifyCode = '';
		for ( $i=0; $i < 4; $i++ ){
			  $randnum = mt_rand(0, $cmax);
			  $verifyCode .= $list[$randnum];           //取出字符，组合成为我们要的验证码字符
		}
		$_SESSION['code'] = $verifyCode;
		@header("Expires: -1");
		@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
		@header("Pragma: no-cache");
		//生成验证码图片
		header("Content-type: image/png");
		$im = imagecreate(90,26);    //生成图片
		$black = imagecolorallocate($im, 0,0,0);     //此条及以下三条为设置的颜色
		$white = imagecolorallocate($im, 255,255,255);
		$gray = imagecolorallocate($im, 200,200,200);
		$red = imagecolorallocate($im, 255, 0, 0);
		imagefill($im,0,0,$white);     //给图片填充颜色

		//将验证码绘入图片
		imagestring($im, 10, 10, 5, $verifyCode, $black);    //将验证码写入到图片中

		for($i=0;$i<90;$i++)  //加入干扰象素
		{
			 imagesetpixel($im, rand() , rand() , $black);    //加入点状干扰素
			 imagesetpixel($im, rand() , rand() , $red);
			 imagesetpixel($im, rand() , rand() , $gray);
			 //imagearc($im, rand()p, rand()p, 20, 20, 75, 170, $black);    //加入弧线状干扰素
			 //imageline($im, rand()p, rand()p, rand()p, rand()p, $red);    //加入线条状干扰素
		}
		imagepng($im);
		imagedestroy($im);
	}
	
}

?>