<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class adminlog_control extends admin_control{
	
	function __construct() {
		parent::__construct();
		$this->on_checkmodel('admins');
	}
        
    //管理记录列表
	function on_list(){
		$adminid = intval(core::gpc('adminid', 'R'));
		$this->view->assign('adminid', $adminid);
		$typeid = intval(core::gpc('typeid', 'R'));
		$this->view->assign('typeid', $typeid);
		$this->view->display('adminlog_list.htm');
	}
        
    //管理记录列表API
	function on_listapi(){
		$userlist = $where = array();
		$pagesize = intval(core::gpc('iDisplayLength', 'P'));
		$start = intval(core::gpc('iDisplayStart', 'P'));
		$searchkey = urldecode(core::gpc('sSearch', 'P'));
		$sEcho = urldecode(core::gpc('sEcho', 'P'));
		$typeid = intval(core::gpc('typeid', 'R'));
		if($typeid >= 1){
			$where['typeid'] = $typeid;
		}
		$adminid = intval(core::gpc('adminid', 'R'));
		if($adminid >= 1){
			$where['aid'] = $adminid;
		}
		if(!empty($searchkey)){
			$where['title'] = array('LIKE' => $searchkey);
		}
		$num = $this->adminlog->total($where);
		$infos = $this->adminlog->index_fetch($where, array('id' => 2), $start, $pagesize);
		foreach($infos as $k => $v){
			$v['addtime'] = date('Y-m-d H:i:s', $v['addtime']);
			if($v['aid'] >= 1){
				$admin = $this->admin->get($v['aid']);
				$adminname = $admin['username'];
			}else{
				$adminname = '未知身份';
			}
			$userlist[] = array($v['id'], $adminname, $v['addtime'], $v['title'], $v['ip'], $v['typeid'], $v['info'], $v['aid']);
		}
		$json['iTotalRecords'] = $num;
		$json['iTotalDisplayRecords'] = $num;
		$json['sEcho'] = $sEcho;
		$json['aaData'] = $userlist;
		echo json_encode($json);
		exit;
	}
        
    //查看礼品记录
	function on_infoapi(){
		$id = intval(core::gpc('id', 'R'));
		$adminlog = $this->adminlog->get($id);
		if(empty($adminlog)){
			$msg = array(
				'stuat' => 2,
				'msg' => "管理记录不存在！",
			);
		}else{
			$admin = $this->admin->get($adminlog['aid']);
			if(empty($admin)){
				$admin['username'] = '管理员已被删除';
			}
			$addtime = date('Y-m-d H:i:s', $adminlog['addtime']);
			$data = '';
			$data .= '<div class="mws-form-row" style="padding: 0px 24px;"><label>记录类型：</label><div class="mws-form-item large">'.$adminlog['title'].'</div></div>';
			$data .= '<div class="mws-form-row" style="padding: 0px 24px;"><label>管理员/ID：</label><div class="mws-form-item large">'.$admin['username'].' / '.$adminlog['aid'].'</div></div>';
			$data .= '<div class="mws-form-row" style="padding: 0px 24px;"><label>操作时间：</label><div class="mws-form-item large">'.$addtime.'</div></div>';
			$data .= '<div class="mws-form-row" style="padding: 0px 24px;"><label>操作IP：</label><div class="mws-form-item large">'.$adminlog['ip'].'</div></div>';
			$data .= '<div class="mws-form-row" style="padding: 0px 24px;"><label>详细信息：</label><div class="mws-form-item large">'.$adminlog['info'].'</div></div>';
			$msg = array('stuat' => 1, 'html' => $data);
		}
		echo json_encode($msg);
		exit;
	}
}

?>