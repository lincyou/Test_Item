<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class admins_control extends admin_control{
	
	function __construct() {
		parent::__construct();
		$this->on_checkmodel('admins');
	}
        
    //管理员管理
	function on_list(){
		$edit = 0;
		$this->view->assign('edit', $edit);
		$admin_group = $this->mcache->read("admingroup");
		$this->view->assign('admin_group', $admin_group);
		$this->view->display('admin_list.htm');
	}
        
    //管理员管理API
	function on_listapi(){
		$userlist = $where = array();
		$pagesize = intval(core::gpc('iDisplayLength', 'P'));
		$start = intval(core::gpc('iDisplayStart', 'P'));
		$searchkey = urldecode(core::gpc('sSearch', 'P'));
		$sEcho = urldecode(core::gpc('sEcho', 'P'));
		if(!empty($searchkey)){
			$where['username'] = array('LIKE' => $searchkey);
		}
		$num = $this->admins->total($where);
		$infos = $this->admins->index_fetch($where, array('id' => 2), $start, $pagesize);
		$admin_group = $this->mcache->read("admingroup");
		foreach($infos as $k => $v){
			if($v['login_time'] >= 1){
				$v['login_time'] = date('Y-m-d H:i:s', $v['login_time']);
			}else{
				$v['login_time'] = "无";
			}
			if(empty($v['login_ip'])){
				$v['login_ip'] = "无";
			}
			$v['groupname'] = $admin_group[$v['groupid']]['name'];
			$userlist[] = array($v['id'], $v['username'], $v['login_time'], $v['login_ip'], $v['groupname'], '');
		}
		$json['iTotalRecords'] = $num;
		$json['iTotalDisplayRecords'] = $num;
		$json['sEcho'] = $sEcho;
		$json['aaData'] = $userlist;
		echo json_encode($json);
		exit;
	}
        
    //增加管理员API
	function on_addapi(){
		$manage['username'] = core::gpc('username', 'P');
		$manage['password'] = core::gpc('password', 'P');
		$manage['groupid'] = intval(core::gpc('groupid', 'P'));
		$admin_group = $this->mcache->read("admingroup");
		if(empty($manage['groupid'])){
			$error = array('msg' => "管理组未设定，建立失败！", 'stuat' => 2);
			echo json_encode($error);
			exit;
		}else if(empty($admin_group[$manage['groupid']]['name'])){
			$error = array('msg' => "管理组不存在！", 'stuat' => 2);
			echo json_encode($error);
			exit;
		}else if($manage['groupid'] == 1 and $this->_admin['groupid'] != 1){
			$error = array('msg' => "非超级管理员不能添加超级管理员！", 'stuat' => 2);
			echo json_encode($error);
			exit;
		}else if(!empty($manage['username']) and !empty($manage['password'])){
			$where = array('username' => $manage['username']);
			$count = $this->admins->total($where);
			if($count >= 1){
				$error = array('msg' => "管理员用户名重复！", 'stuat' => 2);
			}else{
				$manage['code'] = $this->za->make_varchar(6);
				$manage['password'] = md5($manage['password'].$manage['code']);
				$manage['id'] = $this->admins->create($manage);
				if($manage['id'] >= 1){
					/*
					$adminlogdb = array(
						'admin_name' => $this->_admin['username'],
						'id' => $manage['id'],
						'title' => $manage['username'],
					);
					$this->adminlog->admin_log($this->_admin['id'], 38, $adminlogdb);
					*/
					$admingroup = $this->admingroup->get($manage['groupid']);
					$admingroup['num'] += 1;
					$this->admingroup->update($manage['groupid'], $admingroup);
					$error = array('msg' => "添加管理员成功！", 'stuat' => 1, 'id' => $manage['id'], 'systemname' => $admin_group[$manage['groupid']]['name']);
				}else{
					$error = array('msg' => "数据库出错，未保存数据！", 'stuat' => 2);
				}
			}
		}else{
			$error = array('msg' => "账号密码与管理组都不能为空！", 'stuat' => 2);
		}
		echo json_encode($error);
		exit;
	}
        
    //删除管理员
	function on_delapi(){
		$id = intval(core::gpc('id', 'R'));
		$manage = $this->admins->get($id);
		if(empty($manage)){
			$msg = array(
				'stuat' => 2,
				'msg' => "管理员不存在！",
			);
		}else{
			if($id == $this->_admin['id']){
				$msg = array(
					'stuat' => 2,
					'msg' => "不能删除自己！",
				);
				echo json_encode($msg);
				exit;
			}else if($this->_admin['groupid'] != 1 and $manage['groupid'] == 1){
				$msg = array(
					'stuat' => 2,
					'msg' => "非超级管理员不能删除超级管理员！",
				);
				echo json_encode($msg);
				exit;
			}
			//$jiu = $this->adminlog->field_info($manage, 3);
			$delstuat = $this->admins->_delete($id);
			if($delstuat == 1){
				/*
				$adminlogdb = array(
					'admin_name' => $this->_admin['username'],
					'id' => $manage['id'],
					'title' => $manage['username'],
					'jiu' => $jiu,
				);
				$this->adminlog->admin_log($this->_admin['id'], 40, $adminlogdb);
				*/
				$admingroup = $this->admingroup->get($manage['groupid']);
				$admingroup['num'] -= 1;
				$this->admingroup->update($manage['groupid'], $admingroup);
				$msg = array(
					'stuat' => 1,
					'msg' => "删除管理员成功！",
				);
			}else{
				$msg = array(
					'stuat' => 2,
					'msg' => "删除管理员失败！",
				);
			}
		}
		echo json_encode($msg);
		exit;
	}

	//编辑管理员API
	function on_editapi(){
		$id = intval(core::gpc('id', 'R'));
		$manage = $this->admins->get($id);
		if(!empty($manage)){
			if($this->form_submit()) {
				if($this->_admin['groupid'] != 1 and $manage['groupid'] == 1){
					$msg = array('msg' => "您不是超级管理员，不能编辑超级管理员！", 'stuat' => 2);
					echo json_encode($msg);
					exit;
				}
				//$jiu = $this->adminlog->field_info($manage, 3);
				$manage['username'] = core::gpc('username', 'P');
				$password = core::gpc('password', 'P');
				$manage['groupid'] = intval(core::gpc('groupid', 'P'));
				if(!empty($password)){
					$manage['password'] = md5($password.$manage['code']);
				}
				$upstuat = $this->admins->update($manage['id'], $manage);
				if($upstuat >= 1){
					/*
					$xin = $this->adminlog->field_info($manage, 3);
					$liyou = core::gpc('liyou', 'P');
					$adminlogdb = array(
						'admin_name' => $this->_admin['username'],
						'id' => $manage['id'],
						'title' => $manage['username'],
						'jiu' => $jiu,
						'xin' => $xin,
						'liyou' => $liyou,
					);
					if($manage['id'] != $this->_admin['id']){
						$logtypeid = 4;
					}else{
						$logtypeid = 3;
					}
					$this->adminlog->admin_log($this->_admin['id'], $logtypeid, $adminlogdb);
					*/
					$msg['msg'] = "编辑管理员成功！";
					$msg['stuat'] = 1;
				}else{
					$msg['msg'] = "数据库出错，未保存数据！";
					$msg['stuat'] = 2;
				}
			}
		}else{
			$msg = array('msg' => "数据不存在，请重新确认！", 'stuat' => 2);
		}
		echo json_encode($msg);
		exit;
	}
        
    //编辑管理员
	function on_edit(){
		$id = intval(core::gpc('id', 'R'));
		if(empty($id)){
			$id = $this->_admin['id'];
		}
		$user = $this->admins->get($id);
		if(empty($user)){
			$error = array('msg' => "数据不存在，请重新确认！", 'stuat' => 2);
			$this->index->error($error, $menuid);
			exit;
		}
		$admin_group = $this->mcache->read("admingroup");
		$this->view->assign('admin_group', $admin_group);
		$edit = 1;
		$this->view->assign('edit', $edit);
		$this->view->assign('user', $user);
		$this->view->display('admin_list.htm');
	}
}

?>