<?php
!defined('FRAMEWORK_PATH') && exit('FRAMEWORK_PATH not defined.');
class cron_control extends common_control{
	
	function __construct() {
		parent::__construct();
	}
        
    //每天0点更新统计
	function on_count(){
		$datatrue = 0;
		$endtime = strtotime(date('Y-m-d', $_SERVER['time'])) - 1;
		$starttime = $endtime - 86400;
		$logwhere = array('addtime' => array('>=' => $starttime), 'addtime' => array('<=' => $endtime));
		$countlog = $this->countlog->index_fetch($logwhere, array(), 0, 1);
		if(count($countlog) >= 1){
			$datatrue = 1;
			foreach($countlog as $k => $v){
				$old = $v;
			}
		}
		$newuserwhere = array('regtime' => array('>=' => $starttime));
		$newuser = $this->user->total($newuserwhere);

		$newloginwhere = array('logintime' => array('>=' => $starttime));
		$newlogin = $this->user->total($newloginwhere);

		$paymoneywhere = array('endtime' => array('>=' => $starttime));
		$paymoney = $this->logs->sum($paymoneywhere, array('money'));
		$paymoney = $paymoney['moneys'];

		$paynumwhere = array('addtime' => $starttime);
		$paynum = $this->logs->total($paynumwhere);

		$expmoneywhere = array('paytype' => 2, 'addtime' => array('>=' => $starttime));
		$expmoney = $this->logs->sum($expmoneywhere, array('money'));
		$expmoney = $expmoney['moneys'];

		$usermoneywhere = array('money' => array('>' => '0'));
		$usermoney = $this->user->sum($usermoneywhere, array('money'));
		$usermoney = $usermoney['moneys'];
		$data = array(
			'regusernum' => $newuser,
			'loginusernum' => $newlogin,
			'paymoney' => $paymoney,
			'paynum' => $paynum,
			'expmoney' => $expmoney,
			'usermoney' => $usermoney,
			'addtime' => $_SERVER['time'],
		);
		if($datatrue == 0){
			$this->countlog->create($data);
		}else{
			$data['id'] = $old['id'];
			$this->countlog->update($data['id'], $data);
		}
		echo "OK";
		exit;
	}
}

?>