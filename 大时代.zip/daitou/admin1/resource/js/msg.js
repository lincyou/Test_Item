﻿timers = null; //聊天定时器(滚动加载方法中用的)
timers_end = null; //聊天定时器(滚动加载方法中用的)
msg_end_load_time = 0;
var form_stuat = 0;
//聊天加载历史数据
function LoadingDataFn() {
	var dom = '';
	var chat_time = 0;
	var lar = '';
	var info = '';
	var last_i = $('#chat_start_time');
	$('#loading').show();
	jQuery.ajax({
		url: './models.php?m=msg&n=load_msg',
		data: 'chat_start_time=' + last_i.val() + '&uid=' + uid + '&info_type=1',
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				for(var i = json.list.length - 1; i >= 0; i--){
					info = '';
					if(json.list[i].type == 1){
						lar = 'user';
					}else{
						lar = 'admin';
					}
					if(json.list[i].typeid == 1){
						info = json.list[i].msg;
					}else{
						info = '<img style="width:100%" src="' + upload_url + json.list[i].msg + '">';
					}
					dom += '<dl class="row"><dt class="tit"><label for="site_name" class="' + lar + '">' + json.list[i].username + '</label></dt><dd class="opt" id="chat_' + json.list[i].time + '">' + info + '</dd></dl>';
				}
				if(last_i.val() == 0){
					$("#chat_end_time").val(json.chat_end_time);
				}
				chat_time = json.chat_start_time;
				$('#msg_list').prepend(dom);
				if(last_i.val() != 0){
					$(window).scrollTop($('#chat_' + last_i.val()).position().top - $('#chat_' + last_i.val()).height() - 30);
				}else{
					$(window).scrollTop($(document).height());
				}
				last_i.val(json.chat_start_time);
				timers = null;
			}else if(json.stuat == 3 && chat_time > 0){
				//alert('没有更多消息！');
			}else if(chat_time > 0){
				alert(json.msg);
			}
		},
	});
	$('#loading').hide();
};

//聊天加载最新数据
function LoadingDataNew(){
	var timestamp = Date.parse(new Date()) / 1000;
	if(timestamp >= msg_end_load_time && timers_end == null){
		timers_end = 3;
		var dom = '';
		var chat_time = 0;
		var lar = '';
		var info = '';
		var last_i = $('#chat_end_time');
		jQuery.ajax({
			url: './models.php?m=msg&n=load_msg',
			data: 'chat_end_time=' + last_i.val() + '&uid=' + uid + '&info_type=2',
			type: "POST",
			beforeSend: function() {
			},
			success: function(msg) {
				var json = eval("(" + msg + ")");
				if(json.stuat == 1){
					for(var i = 0; i <= json.list.length - 1; i++){
						info = '';
						if(json.list[i].type == 1){
							lar = 'user';
						}else{
							lar = 'admin';
						}
						if(json.list[i].typeid == 1){
							info = json.list[i].msg;
						}else{
							info = '<img style="width:100%" src="' + upload_url + json.list[i].msg + '">';
						}
						dom += '<dl class="row"><dt class="tit"><label for="site_name" class="' + lar + '">' + json.list[i].username + '</label></dt><dd class="opt" id="chat_' + json.list[i].time + '">' + info + '</dd></dl>';
					}
					if($("#chat_start_time").val() == 0){
						$("#chat_start_time").val(json.chat_start_time);
					}
					$('#msg_list').append(dom);
					last_i.val(json.chat_end_time);
				}
			},
		});
		msg_end_load_time = timestamp + 30;
	}
	timers_end = null;
}

//发送聊天信息
function post_msg(msg_type, uid, msg_info){
	jQuery.ajax({
		url: './models.php?m=msg&n=post_msg',
		data: 'msg_type=' + msg_type + '&uid=' + uid + '&msg_info=' + msg_info,
		type: "POST",
		beforeSend: function() {
		},
		success: function(msg) {
			var json = eval("(" + msg + ")");
			if(json.stuat == 1){
				if(timers_end == null){
					msg_end_load_time = Date.parse(new Date()) / 1000;
					LoadingDataNew();
				}
				$('#msg_info').val('');
				$(window).scrollTop($(document).height());
			}else{
				alert(json.msg);
			}
		},
	});
}

$(document).ready(function() {
	if($("#msg_list").length > 0){
		LoadingDataFn();
		timers_end = setInterval(function() {
			LoadingDataNew(); //调用执行上面的加载方法
		}, 10000);
		$("#post_msg").click(function(){
			var msg_info = $("#msg_info").val();
			post_msg(1, uid, msg_info);
		});
		$(window).scrollTop($(document).height());
		$('#upload_img').uploadify({
			formData      : {'type' : 'msg'},
			removeTimeout 	 : 0,
			method	         : 'POST',
			fileTypeDesc	 : '注意:您只能上图片格式的文件!',
			'swf'      : '../upload/uploadify.swf',
			'uploader' : '../upload/uploadify.php',
			'fileTypeExts' : '*.jpg;*.png;*.gif',
			multi: true,
			auto             : true,
			onUploadSuccess  : function(file, data, response) {{
				var json = eval("(" + data + ")");
				if(json.rename != undefined){
					post_msg(2, uid, json.rename);
				}else{
					alert('上传图片失败，请重试！');
				}
			}}
		});
	}
});

//聊天滚动加载方法
$(window).scroll(function() {
	//当时滚动条离顶部60px时开始加载下一页的内容
	if($(window).scrollTop() <= 60 && timers == null) {
		clearTimeout(timers);
		//这里还可以用 [ 延时执行 ] 来控制是否加载 （这样就解决了 当上页的条件满足时，一下子加载多次的问题啦）
		timers = setTimeout(function() {
			LoadingDataFn(); //调用执行上面的加载方法
		}, 300);
	}
});