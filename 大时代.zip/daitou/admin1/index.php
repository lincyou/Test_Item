<?php
set_time_limit(0);
// 调试模式: 1 打开，0 关闭
define('DEBUG', 2);
$file = explode("/", $_SERVER['PHP_SELF']);
define('ADMIN_PATH', $file[count($file) - 2]);
$filesubstr = strlen(ADMIN_PATH) + 10;
define('BBS_PATH', str_replace('\\', '/', substr(__FILE__, 0, -$filesubstr)));
//define('BBS_PATH', '../');
define('FRAMEWORK_PATH', BBS_PATH.'framework/');
// 加载应用的配置文件
$conf = include BBS_PATH.'conf/conf.php';
$adminconf = include BBS_PATH.ADMIN_PATH.'/conf/conf.php';
$conf = array_merge($conf, $adminconf);
// 临时目录
define('FRAMEWORK_TMP_PATH', $conf['tmp_path']);
// 日志目录
define('FRAMEWORK_LOG_PATH', $conf['log_path']);
include FRAMEWORK_PATH.'core.php';
include BBS_PATH.ADMIN_PATH.'/control/common_control.class.php';
core::init();
core::ob_start();
core::run();
// 完毕
?>