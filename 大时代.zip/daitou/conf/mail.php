<?php
// mail发送方式, 0:PHP内置函数 mail(), 1: SMTP 方式
return array(
	'sendtype' => 1,

	'smtplist' => array (
  0 => 
  array (
    'email' => 'daxue_2shuxue@163.com',
    'host' => 'smtp.163.com',
    'port' => '25',
    'user' => 'daxue_2shuxue@163.com',
    'pass' => '123456789jjj',
  ),
)
);

?>