<?php
return array('whitelist' => array (
), 'blacklist' => array (
));
?>