<?php

$partner = '2088002165506865';//合作伙伴ID
$security_code = '9ld5aud1pk9sl06lmx7mwwtxhr9gnscv';//安全检验码
$seller_email = 'zhuojie15@163.com';//卖家邮箱
$_input_charset = "utf-8"; //字符编码格式  目前支持 GBK 或 utf-8
$sign_type = "MD5"; //加密方式  系统默认(不要修改)
$transport= "http";//访问模式,你可以根据自己的服务器是否支持ssl访问而选择http以及https访问模式(系统默认,不要修改)
$notify_url = "";// 异步返回地址
$return_url = ""; //同步返回地址
$show_url   = ""  //你网站商品的展示地址,可以为空

?>