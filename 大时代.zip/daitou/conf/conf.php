<?php
 
/**************************************************************************************************
 *
 *	【注意】：
 *		请不要使用 Windows 的记事本编辑此文件！此文件的编码为UTF-8编码，不带有BOM头！
 *		建议使用UEStudio, Notepad++ 类编辑器编辑此文件！
 *
***************************************************************************************************/

// 全局配置变量

return array (
	
	// 数据库配置， type 为默认的数据库类型，可以支持多种数据库: mysql|pdo|mongodb
	'db' => array (
		'type' => 'mysqli',
		'mysqli' => array (
			'master' => array (
					'host' => '127.0.0.1',
					'user' => 'root',
					'password' => 'xiaoya1271310216',
					'name' => 'daitou',
					'charset' => 'utf8',
					'tablepre' => 'fav_',
					'engine'=>'MyISAM',
			),
			'slaves' => array (
			)
		),
		'pdo' => array (
			'master' => array (
					'host' => 'localhost',
					'user' => 'root',
					'password' => 'root',
					'name' => 'daitou',
					'charset' => 'utf8',
					'tablepre' => 'fav_',
					'engine'=>'MyISAM',
			),
			'slaves' => array (
			)
		),
		'mongodb' => array(
			'master' => array (
					'host' => '10.0.0.253:27017',
					'user' => '',
					'password' => '',
					'name' => 'test',
					'tablepre' => '',
			),
			'slaves' => array (
			)
		),
	),	
	'cache_colse' => 0,
	// 缓存服务器的配置，支持: memcache|ea|apc|redis
	'cache' => array (
		'enable'=>0,
		'type'=>'memcache',
		'memcache'=>array (
			'multi'=>0,
			'host'=>'127.0.0.1',
			'port'=>'11211',
		)
	),

	// 唯一识别ID
	'app_id' => 'api',
	
	// 站点名称
	'app_name' => 'fuli',
	
	// 站点介绍
	'app_brief' => '',
		
	// 应用的路径，用于多模板互相包含，需要时，填写绝对路径： 如: http://www.domain.com/
	'app_url' => 'http://www.dashidai222222.com/',
	
	// CDN 缓存的静态域名，如 http://static.domain.com/
	'static_url' => 'http://www.dashidai222222.com/',
	
	// 模板使用的目录，按照顺序搜索，这样可以支持风格切换,结果缓存在 tmp/yhq_xxx_control.htm.php
	'view_path' => array(BBS_PATH.'plugin/view_blue/', BBS_PATH.'view/'), 
	
	// 数据模块的路径，按照数组顺序搜索目录
	'model_path' => array(BBS_PATH.'model/'),
	
	// 业务控制层的路径，按照数组顺序搜索目录，结果缓存在 tmp/bbs_xxx_control.class.php
	'control_path' => array(BBS_PATH.'control/'),
	
	// 临时目录，需要可写，可以指定为 linux /dev/shm/ 目录提高速度
	'tmp_path' => BBS_PATH.'tmp/',
	
	// 缓存目录，需要可写，可以指定为 linux /dev/shm/ 目录提高速度
	'cache_path' => BBS_PATH.'cache/',
	
	// 上传目录，需要可写，保存用户上传数据的目录
	'upload_path' => BBS_PATH.'upload/',

	// 各种文件锁的保存路径
	'lock_path' => BBS_PATH.'lock/',
	
	// 锁类型，1为memcache，2为MYSQL内存表，其他为文件锁
	'lock_type' => 2,
	
	// 模板的URL，用作CDN时请填写绝对路径，需要时，填写绝对路径： 如: http://www.domain.com/upload/
	'upload_url' => 'http://daitou.01717.com/upload/',
	
	// 日志目录，需要可写，如果您不需要日志，留空即可
	'log_path' => BBS_PATH.'log/',
		
	'plugin_path' => BBS_PATH.'plugin/',
	
	'cookiepre'=> 'api_',
	
	// 是否开启 URL-Rewrite
	'urlrewrite' => 0,
	
	// 加密KEY，
	'public_key' => '972b27859503eed43edea25b09264404',
	
	'timeoffset' => '-8',
	'cookie_keeptime' => 86400,
	
	// SEO
	'seo_title' => '1234',		// 首页的 title，如果不设置则为网站名称
	'seo_keywords' => '2',		// 首页的 keyword
	'seo_description' => '1',	// 首页的 description
	'china_icp' => '3',			// icp 备案号，也只有在这神奇的国度有吧。
	
	// 注册相关
	'reg_on' => 1,				// 是否开启注册
	'iptable_on' => 0,			// IP 规则，白名单，黑名单
	'installed' => 1,			// 是否安装的标志位
	'clearmobile' => 'abcsdd$1csvx',

	'open_stuat' => 1,
	'close_info' => '123',
	'licai_yongjin' => 10,
	'fenhonglv' => '2',
	'shouxufei' => '2',
	'asiteurl' => 'https://www.sx168.com?intr=boss888',
	'yongjin1' => '1',
	'yongjin2' => '2',
	'yongjin3' => '3',
	'yongjin4' => '4',
	'yongjin5' => '5',
	'yongjin6' => '6',
	'yongjin7' => '7',
	'yongjin8' => '8',
	'yongjin9' => '9',
	'yongjin10' => '10',
	'shiwu' => 0,//事务模式，1为程序事务，2为数据库事务

	'kf_url' => 'tencent://message/?uin=14682454&Site=自己&Menu=yes',//客服地址
	'userbankcard_num' => '5',//用户最大可绑卡数
	'min_in_money' => '100',//最小充值金额
	'min_out_money' => '100',//最小提现金额
	'max_out_money_num' => '5',//一日最大可提现次数
	'dama_bilv' => '30',//打码量比例，未完成的扣除手续费,10表示10%
	'dama_shouxufei' => '2',//打码量未完成手续费，10表示提现金额的10%作为手续费
	'in_money_shouxufei' => '0.2',//充值手续费，0表示不收取手续费，10表示10%作为手续费
	'peilv_1' => '9.5',//定位胆赔率
	'peilv_2' => '59',//冠亚赔率
	'tip_1' => '从“第一名~第十名”中任选1个或以上号码，所选号码与其对应的名次和车号相同，即视为中奖。<br>如：冠选择01<br>开奖号码的第一个号码为01，即为中奖。',//定位胆说明
	'tip_2' => '任选第一名与第二名的中奖号码，所选号码与开奖结果两个号码相同，即视为中奖。<br>如：冠选择01，亚选择02<br>开奖号码的第一个号码为01，第二个号码为02，即为中奖。',//冠亚说明
	'daitou_money' => '0.39
1.07
2.24
4.26
7.75
13.78
24.19
42.17
74.00
142.45',
	'daitou_money1' => '0.02
0.06
0.17
0.36
0.72
1.41
2.72
5.50
10.50
20.35',
	'daitou_num' => '16',
	'daitou_num_num' => '4',
	'daitou_num1' => '11',
	'client_version' => '1.0',
	'client_end_tuichu' => '23:59:00',
	'client_down_url' => 'http://www.baidu.com',
	'client_tip' => '建议200本金起挂，设置0.1仓位
每增加200本金，增加0.1仓位
故：2000本金，仓位设置1
     10000本金，仓位设置5
... 以此类推，设置好后点击开始投注即可
见好就收，做常胜将军',
	'client_alert' => '本软件是一套用于对中国大陆发行的国家或地方彩票进行数据统计及分析研究的软件系统，彩市有风险，投资需谨慎。彩票软件只是一个工具，本公司对您使用本软件进行彩票投注等经济活动不承担任何民事或刑事责任，使用本软件得到的投注结果仅供参考，因操作不当或因软件本身bug（漏洞）导致运算可能出现的偏差，本公司亦不承担由此引起的责任或经济损失，使用本软件表示您已经认真考虑并同意本申明，但为了帮助您控制投资彩票带来的风险，我们再次请您确认已经了解并同意本申明，谢谢您的合作！请选择您是否同意本条款？',
	'all_gonggao' => '111111',
	'wanfa2_z1' => '7,9,13,15',
	'wanfa2_z2' => '8,10,12,14',
	'wanfa2_z3' => '4,5,6,11,16,17',
	'max_jiangjin' => '100000',
	'client_hash' => '789',
	'iaurlcnm' => 'www.dashidai111111.com|线路1,www.dashidai222222.com|线路2,www.dashidai333333.com|线路3,www.dashidai555555.com|线路5,www.dashidai666666.com|线路6',
	'msg_info1' => '尊敬的用户，您于{date}，成功提款{money}元，已出账，请查收，谢谢。',//出款站内信模板
	'msg_info2' => '尊敬的用户，您于{date}，获得佣金{money}元，已入账，请查收，谢谢。',//佣金到账站内信模板
	'msg_info3' => '尊敬的用户，您于{date}，因{yuanyin}原因，账户发生变动{money}元，请查收，谢谢。',//派奖站内信模板
	'msg_info4' => '尊敬的用户，您于{date}，成功充值{money}元，已入账，请查收，谢谢。',//入款站内信模板
	'site1_login' => '1',//网站1登录允许状态
	'site2_login' => '1',//网站2登录允许状态
	'site1_daitou_money' => '0',//网站1接受的投注金额比例
	'site2_daitou_money' => '0.1',//网站2接受的投注金额比例
);
?>